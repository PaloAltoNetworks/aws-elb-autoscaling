"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""
from __future__ import print_function

import sys
import boto3
import botocore
import json
import logging
import time
import decimal
import uuid
import logging

sys.path.append('lib/')
import pan.asglib as lib

sys.path.append('dnslib/')
import pan_client as dns

# Enable creation of S3 bucket per-ASG
enable_s3=False
num_nlb_port=1280
start_nlb_port=81
num_fw_az=2

# Global Tunnables
dig=True
asg_tag_key="PANW-ASG"
asg_delay=30

####### GLobal Variables ############
stackname=""
region=""
ilb_tag=""
elb_name=""
sg_vpc=""
sg_mgmt=""
sg_untrust=""
sg_trust=""
keyname=""
iamprofilebs=""
s3master=""
subnetmgmt=""
subnetuntrust=""
subnettrust=""
routetableidtrust=""
vpcid =""
imageID=""
ScalingPeriod=300
ScaleUpThreshold=50
ScaleDownThreshold=30
ScalingParameter=""
instanceType=""
MinInstancesASG=1
MaximumInstancesASG=3
LambdaExecutionRole=""
LambdaENISNSTopic=""
ASGNotifierRole=""
ASGNotifierRolePolicy=""
LambdaS3Bucket=""
PanS3KeyTpl=""
KeyPANWFirewall=""
KeyPANWPanorama=""
PanoramaAdminUser=""
SubnetIDNATGW=""
SubnetIDLambda=""
LambdaENIQueue=""
PIP=""
PDG=""
PTPL=""
Hostname=""
error_line="--------ERROR------ERROR-----ERROR------ERROR-------"

######## BOTO3 Clients and Resources #############
s3 = boto3.client('s3')
asg = boto3.client('autoscaling')
ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client
lambda_client = boto3.client('lambda')
iam = boto3.client('iam')
events_client = boto3.client('events')
cloudwatch = boto3.client('cloudwatch')
elb = boto3.client('elb')
elbv2 = boto3.client('elbv2')


####### FUNCTIONS ############
def random_string(string_length=10):
    """

    :param string_length:
    :return:
    """
    random = str(uuid.uuid4()) 
    random = random.replace("-","") 
    return random[0:string_length]

def common_alarm_func_add(asg_name, metricname, namespace, arn_scalein, arn_scaleout, alarmname, desc, Unit):
    """

    Method that supports a common interface to add cloud watch alarms along with the associated threshold
    metrics.

    :param asg_name: Name of the ASG that this alarm is associated with.
    :param metricname: Name of the metric.
    :param namespace: Name of the namespace.
    :param arn_scalein: ARN of the scale-in metric.
    :param arn_scaleout: ARN of the scale-out metric.
    :param alarmname: Name of the alarm that will be raised.
    :param desc: Description of the alarm
    :param Unit: The unit to be used.
    :return: bool
    """
    d1=desc+ " High"
    a1=alarmname + '-high'
    try:
        cloudwatch.put_metric_alarm(AlarmName=a1, AlarmDescription=d1,
            AlarmActions=[arn_scaleout],
            ActionsEnabled=True, MetricName=metricname, EvaluationPeriods=1,
            Threshold=float(ScaleUpThreshold), Statistic="Average", Namespace=namespace,
            ComparisonOperator="GreaterThanThreshold", Period=ScalingPeriod, Unit=Unit)
    except Exception as e:
        logger.error('Failed to add High Alarm: ' + desc + ' for ASG: ' + asg_name)
        logger.error("[Alarm High Add]: {}".format(e))
        return False

    a1=alarmname + '-low'
    d1=desc+ " Low"
    try:
        cloudwatch.put_metric_alarm(AlarmName=a1, AlarmDescription=d1,
            AlarmActions=[arn_scalein],
            ActionsEnabled=True, MetricName=metricname, EvaluationPeriods=1,
            Threshold=float(ScaleDownThreshold), Statistic="Average", Namespace=namespace,
            ComparisonOperator="LessThanThreshold", Period=ScalingPeriod,
            Unit=Unit)
    except Exception as e:
        logger.error('Failed to add Low Alarm: ' + desc + ' for ASG: ' + asg_name)
        logger.error("[Alarm Low Add]: {}".format(e))
        return False

    return True

def common_alarm_func_del(alarmname):
    """
    Common interface to delete alarms
    :param alarmname: Name of the alarm to delete.
    :return: None
    """
    a1=alarmname + '-high'
    cloudwatch.delete_alarms(AlarmNames=[a1])

    a1=alarmname + '-low'
    cloudwatch.delete_alarms(AlarmNames=[a1])
    return

## CloudWatch Alarms
def AddDataPlaneCPUUtilization(asg_name, arn_scalein, arn_scaleout):
    """
    Method to create the DataPlaneCPUUtilization Alarm. This alarm
    will trigger when the Data Plane CPU Utilization exceeds the
    specified threshold.

    :param asg_name: Name of the ASG
    :param arn_scalein: ARN of the scale-in metric
    :param arn_scaleout: ARN of the scale-out metric
    :return: bool
    """
    logger.info('Creating dataPlane CPU High CloudWatch alarm for ASG: ' + asg_name)
        
    alarmname= asg_name + '-cw-cpu'
    return common_alarm_func_add(asg_name, "DataPlaneCPUUtilizationPct", lib.get_cw_name_space(stackname, asg_name), arn_scalein, arn_scaleout,
            alarmname, "DataPlane CPU Utilization", 'Percent')

def DelDataPlaneCPUUtilization(asg_name):
    """
    Method to delete the DataPlaneCPUUtilization Alarm. This alarm
    will trigger when the Data Plane CPU Utilization exceeds the
    specified threshold.

    :param asg_name: Name of the ASG
    :return: None
    """
    logger.info('Deleting dataPlane CPU High CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-cpu'
    common_alarm_func_del(alarmname)
    return

def AddActiveSessions(asg_name, arn_scalein, arn_scaleout):
    """
    Method to create the ActiveSessions Alarm. This alarm
    will trigger when the Active Sessions exceeds the
    specified threshold.

    :param asg_name: Name of the ASG
    :param arn_scalein: ARN of the scale-in metric
    :param arn_scaleout: ARN of the scale-out metric
    :return: bool
    """
    logger.info('Creating Active Sessions CloudWatch alarm for ASG: ' + asg_name)

    alarmname= asg_name + '-cw-as'
    return common_alarm_func_add(asg_name, "panSessionActive", lib.get_cw_name_space(stackname, asg_name), arn_scalein, arn_scaleout,
            alarmname, "Active Sessions", 'Count')

def DelActiveSessions(asg_name):
    """
    Method to delete the Active Sessions alarm

    :param asg_name: Name of the ASG
    :return: None
    """
    logger.info('Deleting Active Sessions CloudWatch alarm for ASG: ' + asg_name)

    alarmname= asg_name + '-cw-as'
    common_alarm_func_del(alarmname)
    return

def AddSessionUtilization(asg_name, arn_scalein, arn_scaleout):
    """
    Method to create the SessionUtilization Alarm. This alarm
    will trigger when the SessionUtilization exceeds the
    specified threshold.

    :param asg_name: Name of the ASG
    :param arn_scalein: ARN of the scale-in metric
    :param arn_scaleout: ARN of the scale-out metric
    :return: bool
    """
    logger.info('Creating Session Utilization CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-su'
    return common_alarm_func_add(asg_name, "panSessionUtilization", lib.get_cw_name_space(stackname, asg_name), arn_scalein, arn_scaleout,
            alarmname, "Session Utilization", 'Percent')

def DelSessionUtilization(asg_name):
    """
        Method to delete the Session Utilization alarm

        :param asg_name: Name of the ASG
        :return: None
    """
    logger.info('Deleting Session Utilization CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-su'
    common_alarm_func_del(alarmname)
    return

def AddGPGatewayUtilization(asg_name, arn_scalein, arn_scaleout):
    """
        Method to create the GPGatewayUtilization Alarm. This alarm
        will trigger when the GPGatewayUtilization exceeds the
        specified threshold.

        :param asg_name: Name of the ASG
        :param arn_scalein: ARN of the scale-in metric
        :param arn_scaleout: ARN of the scale-out metric
        :return: bool
    """
    logger.info('Creating GP Gateway Utilization CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-gpu'
    return common_alarm_func_add(asg_name, "panGPGatewayUtilizationPct", lib.get_cw_name_space(stackname, asg_name), arn_scalein, arn_scaleout,
            alarmname, "GP Gateway Utilization", 'Percent')

def DelGPGatewayUtilization(asg_name):
    """
    Method to delete the GP Session Utilization alarm

    :param asg_name: Name of the ASG
    :return: None
    """
    logger.info('Deleting GP Gateway Utilization CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-gpu'
    common_alarm_func_del(alarmname)
    return

def AddGPActiveTunnels(asg_name, arn_scalein, arn_scaleout):
    """
        Method to create the GPActiveTunnels Alarm. This alarm
        will trigger when the GP Active Tunnels  exceeds the
        specified threshold.

        :param asg_name: Name of the ASG
        :param arn_scalein: ARN of the scale-in metric
        :param arn_scaleout: ARN of the scale-out metric
        :return: bool
    """
    logger.info('Creating GP Active Tunnels CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-gpat'
    return common_alarm_func_add(asg_name, "panGPGWUtilizationActiveTunnels", lib.get_cw_name_space(stackname, asg_name), arn_scalein, arn_scaleout,
                        alarmname, "GP Gateway Utilization", 'Count')

def DelGPActiveTunnels(asg_name):
    """
    Method to delete the GP GPActiveTunnels alarm
    
    :param asg_name: Name of the ASG
    :return: None
    """

    logger.info('Deleting GP Active Tunnels CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-gpat'
    common_alarm_func_del(alarmname)
    return

def AddDataPlaneBufferUtilization(asg_name, arn_scalein, arn_scaleout):
    """
    Method to create the DataPlaneBufferUtilization Alarm. This alarm
    will trigger when the DataPlaneBufferUtilization exceeds the
    specified threshold.

    :param asg_name: Name of the ASG
    :param arn_scalein: ARN of the scale-in metric
    :param arn_scaleout: ARN of the scale-out metric
    :return: bool
    """
    logger.info('Creating DP Buffer Utilization CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-dpb'
    return common_alarm_func_add(asg_name, "DataPlanePacketBufferUtilization", lib.get_cw_name_space(stackname, asg_name), arn_scalein, arn_scaleout,
            alarmname, "Data Plane Packet Buffer Utilization", 'Percent')

def DelDataPlaneBufferUtilization(asg_name):
    """
    Method to delete the DatePlaneBufferUtilization  alarm

    :param asg_name: Name of the ASG
    :return: None
    """
    logger.info('Deleting DP Packet Buffer Utilization CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-dpb'
    common_alarm_func_del(alarmname)
    return

def AddSessionSslProxyUtilization(asg_name, arn_scalein, arn_scaleout):
    """
    Method to create the SessionSslProxyUtilization Alarm. This alarm
    will trigger when the SessionSslProxyUtilization exceeds the
    specified threshold.

    :param asg_name: Name of the ASG
    :param arn_scalein: ARN of the scale-in metric
    :param arn_scaleout: ARN of the scale-out metric
    :return: bool
    """
    logger.info('Creating Session SSL Proxy  Utilization CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-sspu'
    return common_alarm_func_add(asg_name, "panGPGatewayUtilizationPct", lib.get_cw_name_space(stackname, asg_name), arn_scalein, arn_scaleout,
                        alarmname, "Session SSL Proxy Utilization", 'Percent')
    return

def DelSessionSslProxyUtilization(asg_name):
    """
    Method to delete the SessionSslProxyUtilization alarm
    
    :param asg_name: Name of the ASG
    :return: None
    """
    logger.info('Deleting Session SSL Proxy Utilization CloudWatch alarm for ASG: ' + asg_name)
    alarmname= asg_name + '-cw-sspu'
    common_alarm_func_del(alarmname)
    return

cw_func_add_alarms = {  'DataPlaneCPUUtilizationPct': AddDataPlaneCPUUtilization,
                        'panSessionActive': AddActiveSessions,
                        'panSessionUtilization': AddSessionUtilization,
                        'panGPGatewayUtilizationPct': AddGPGatewayUtilization,
                        'panGPGWUtilizationActiveTunnels': AddGPActiveTunnels,
                        'panSessionSslProxyUtilization': AddSessionSslProxyUtilization,
                        'DataPlanePacketBufferUtilization': AddDataPlaneBufferUtilization}

cw_func_del_alarms = {  'DataPlaneCPUUtilizationPct': DelDataPlaneCPUUtilization,
                        'panSessionActive': DelActiveSessions,
                        'panSessionUtilization': DelSessionUtilization,
                        'panGPGatewayUtilizationPct': DelGPGatewayUtilization,
                        'panGPGWUtilizationActiveTunnels': DelGPActiveTunnels,
                        'panSessionSslProxyUtilization': DelSessionSslProxyUtilization,
                        'DataPlanePacketBufferUtilization': DelDataPlaneBufferUtilization}

def create_asg_life_cycle(asg_name):
    """
    Method to register ASG life cycle hook actions.


    When and ASG lifecycle hook is triggered the targets as registered
    by this method get triggered with the appropriate data fields.

    :param asg_name: Name of the ASG.
    :param ip_address: IP address of the instance
    :return: bool
    """
    logger.info('Creating Life Cycle Hook for ASG: ' + asg_name)
    hookname=asg_name + '-life-cycle-launch'

    metadata = {
                'MGMT': subnetmgmt, 'UNTRUST': subnetuntrust, 'TRUST': subnettrust, 'KeyPANWFirewall': KeyPANWFirewall,
                'KeyPANWPanorama': KeyPANWPanorama, 'LambdaENIQueue': LambdaENIQueue,
                'PanoramaAdminUser': PanoramaAdminUser
    }
    
    try:
        asg.put_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name,
            LifecycleTransition="autoscaling:EC2_INSTANCE_LAUNCHING",
            RoleARN=ASGNotifierRole, NotificationTargetARN=LambdaENISNSTopic,
            DefaultResult="ABANDON", HeartbeatTimeout=300,
            NotificationMetadata=json.dumps(metadata))
    except Exception as e:
        logger.error("[ASG LifeCycle Hook Launch. ROLLBACK]: {}".format(e))
        return False
    
    hookname=asg_name + '-life-cycle-terminate'
    try:
        asg.put_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name,
            LifecycleTransition="autoscaling:EC2_INSTANCE_TERMINATING",
            RoleARN=ASGNotifierRole, NotificationTargetARN=LambdaENISNSTopic,
            DefaultResult="CONTINUE", HeartbeatTimeout=300,
            NotificationMetadata=json.dumps(metadata))
    except Exception as e:
        logger.error("[ASG LifeCycle Hook Terminate. ROLLBACK]: {}".format(e))
        return False
    
    return True

def create_asg():
    """
    Method to create an Auto Scale Group with the configuration
    provided.

    .. note:: This method performs the following critical functions

       - reads in configuration from an S3 bucket
       - creates a launch configuration
       - creates an ASG
       - associates the policies with the ASG
       - registers to ASG life-cycle hook events and provides handlers for these events.

    :return:
    """
    lc_name= lib.get_lc_name(stackname, ELBTargetGroupName)

    logger.info('Creating launch-config for a new ASG: ' + lc_name)
    userdata='vmseries-bootstrap-aws-s3bucket=' + s3master
    
    try:
        response=asg.create_launch_configuration(LaunchConfigurationName=lc_name, 
                ImageId=imageID, KeyName=keyname, SecurityGroups=[sg_untrust], InstanceType=instanceType,
                AssociatePublicIpAddress=False, EbsOptimized=True,
                IamInstanceProfile=iamprofilebs,
                BlockDeviceMappings=[
                        {'DeviceName': "/dev/xvda", 
                         'Ebs': 
                            {'DeleteOnTermination': True,
                             'VolumeType': 'gp2'
                            }
                        }
                ],
                UserData=userdata)
    except Exception as e:
         logger.error("[ASG LC error]: {}".format(e))
         return False
    #Get ELB ARN
    tgtGrp = elbv2.describe_target_groups(Names=[ELBTargetGroupName])
    if tgtGrp == None:
        tgtGrp_arn = None
        logger.info('ELB target group is not found!')
    else:
        tgtGrp_d = tgtGrp['TargetGroups']
        tgtGrp_arn = tgtGrp_d[0].get('TargetGroupArn')
    print("targetgroup arn: " + tgtGrp_arn)
    print( "ELBTargetGroupName: " +ELBTargetGroupName)
 
    asg_name = lib.get_asg_name(stackname, ELBTargetGroupName)
    logger.info('Creating Auto-Scaling Group with name: ' + asg_name)
    tags={'ResourceId': asg_name, 'ResourceType': 'auto-scaling-group', 'Key': 'Name', 'Value': asg_name, 'PropagateAtLaunch':True}
    logger.info(' Subnet Untrust List: ' + subnetuntrust)
    try:
        response=asg.create_auto_scaling_group(AutoScalingGroupName=asg_name, LaunchConfigurationName=lc_name,
                MinSize=MinInstancesASG, MaxSize=MaximumInstancesASG, DesiredCapacity=MinInstancesASG,
                DefaultCooldown=ScalingPeriod, TargetGroupARNs=[tgtGrp_arn],
                VPCZoneIdentifier=subnetuntrust,
                Tags=[tags],
                HealthCheckGracePeriod=900)
    except Exception as e:
         logger.error("[ASG create error]: {}".format(e))
         return False
         
    #if create_asg_life_cycle(asg_name, AvailabilityZone) == False: 
    if create_asg_life_cycle(asg_name) == False:    
        return False
    
    scalein=asg_name + '-scalein'
    try:
        response = asg.put_scaling_policy(AutoScalingGroupName=asg_name, PolicyName=scalein, AdjustmentType='ChangeInCapacity',
            ScalingAdjustment=-1, Cooldown=600)
        arn_scalein=response['PolicyARN']
    except Exception as e:
         logger.error("[ASG ScaleIn12 Policy]: {}".format(e))
         return False
         
    scaleout=asg_name + '-scaleout'
    try:
        response = asg.put_scaling_policy(AutoScalingGroupName=asg_name, PolicyName=scaleout, AdjustmentType='ChangeInCapacity',
            ScalingAdjustment=1, Cooldown=600)
        arn_scaleout=response['PolicyARN']
    except Exception as e:
         logger.info("[ASG ScaleOut123]: {}".format(e))
         return False
        
    logger.info('ARN of Scale In and Scale Out: ' + arn_scalein + ' ' + arn_scaleout)
    logger.info('Adding Cloud Watch Alarm : ' + ScalingParameter + ' for ASG: ' + asg_name)
    if cw_func_add_alarms[ScalingParameter](asg_name, arn_scalein, arn_scaleout) == False:
        return False
        
    return True         


def getAz(ip, response_ilb):
    """
    Method to return the availability zone that a
    configured IP address belongs to.

    :param ip:
    :param response_ilb:
    :return:
    """
    for i in response_ilb['NetworkInterfaces']:
        logger.info('GetAz: Details about Internal Load Balancer')
        for k in i['PrivateIpAddresses']:
            logger.info('GetAz: IP Address of ILB is :' + k['PrivateIpAddress'])
            if k['PrivateIpAddress'] == ip:
                return i['AvailabilityZone']

    return None

def check_and_send_message_to_queue(queue_url, str_message):
    """
    Method to check the refresh the queue.

    :param queue_url:
    :param str_message:
    :return: 
    """
    msg_str, msg_sent_timestamp, receipt_handle = lib.get_from_sqs_queue(queue_url, 20, 5)

    if not msg_str:
        logger.warning('Unable to retrieve message during this cycle, generating new')
        lib.send_message_to_queue(queue_url, str_message)
        return 
    msg_data = json.loads(msg_str)
    
    msg_ts = float(msg_sent_timestamp) * 0.001
    logger.info('Message from queue: {}'.format(msg_data))
    current_time = time.time()

    logger.info('msg ts: {} current ts: {}'.format(msg_ts, current_time))

    if (current_time - msg_ts) > 259200:
        logger.info('Message in queue needs to be updated')
        lib.send_message_to_queue(queue_url, str_message)
        lib.delete_message_from_queue(queue_url, receipt_handle)  
    else:
        logger.info('Message in queue is still current.')

def firewall_asg_update(event, context):
    """
    Method to monitor the asg in the supported AZs.

    The actions performed by this function are:
        - if asg doesn't exist, create asg. 
        - Before create asg, it will remove the launch config if exists.
          Then create new launch config.
    :param event: Encodes all the input variables to the lambda function, when
                  the function is invoked.
                  Essentially AWS Lambda uses this parameter to pass in event
                  data to the handler function.
    :type event: dict

    :param context: AWS Lambda uses this parameter to provide runtime information to your handler.
    :type context: LambdaContext

    :return: None
    """

    print("Firewall ASG update Time remaining (MS):", context.get_remaining_time_in_millis())
    search = lib.get_asg_name(stackname, ELBTargetGroupName)
    asg_response=asg.describe_auto_scaling_groups(AutoScalingGroupNames=[search])
    print(asg_response)
    if len(asg_response['AutoScalingGroups']) == 0:
        logger.warning('ASG is not found, creating ASG')
        
        lc_name= lib.get_lc_name(stackname, ELBTargetGroupName) 
        #logger.warning('LCname' + lc_name)    
        asg_response = asg.describe_launch_configurations(LaunchConfigurationNames=[lc_name])
        if len(asg_response['LaunchConfigurations']) != 0:
            logger.info('Deleting Lanuch-configuration for ASG: ' + search)
            try:
                asg.delete_launch_configuration(LaunchConfigurationName=lc_name)
            except Exception as e:
                logger.error('Could not remove ASG LC. Reason below')
                logger.error("[ASG DELETE LC]: {}".format(e))

        if create_asg() == False:
            lib.remove_asg(stackname, ELBTargetGroupName, ScalingParameter, KeyPANWPanorama, False, False)
            print(error_line)
            
    print("Time remaining return firewall_asg_update (MS):", context.get_remaining_time_in_millis())

def network_load_balancer_update(event, context):
    """
    Method to monitor NLB sqs and update firewall nat rules

    The actions performed by this function are:
        - find all firewalls of COMMIT state in firewall table and apply
          nat rules of all ILB IPs in ILB table
        - read new msg from ILB sqs and update ilb table and firewall rules

    :param event: Encodes all the input variables to the lambda function, when
                  the function is invoked.
                  Essentially AWS Lambda uses this parameter to pass in event
                  data to the handler function.
    :type event: dict

    :param context: AWS Lambda uses this parameter to provide runtime information to your handler.
    :type context: LambdaContext

    :return: None
    """
    print("ILB update Time remaining (MS):", context.get_remaining_time_in_millis())   
    logger.info('Running internal load balancer update')
    fwcontext = lib.get_ssl_context()
    total_fw_az = len(fw_azs)

    #Search for COMMIT in firewall table
    try:
        response = lib.firewall_table_get_all_in_state(stackname, region, 'COMMIT')
        for fw in response['Items']:
            nlb_port_mask = []
            for i in range (0, (num_nlb_port)/64):
                nlb_port_mask.append(0)

            set_nat = True
            # Find all the nlb in commit state
            nlb_response=lib.nlb_table_get_all_in_state(stackname, region, 'COMMIT')
        
            for nlb in nlb_response['Items']:
                nlb_port = nlb['TCPPort']
                dns_name = nlb['DNSName']
                nlb_vpc = nlb['VPCID']
                nlb_vpc_cidr = nlb['VPCCidr']
                rule_mask_index = int((nlb_port-start_nlb_port)/64)
                nlb_bit = int((nlb_port-start_nlb_port)%64)
                nlb_port_mask[rule_mask_index] |= 1<<nlb_bit
                fw_rule_mask = long(fw['iLBRuleMask'+str(rule_mask_index)], 0)
            
#               # Skip if it's configured on firewall
                if fw_rule_mask & (1 << nlb_bit) != 0:
                    continue
                
                #Add NAT rules on firewall via panorama
                         
                logger.info('Config firewall NAT rule from panorama')
                if lib.config_firewall_add_nat_rule_panorama(PIP,KeyPANWPanorama,PanoramaAdminUser,PDG,dns_name,nlb_port,nlb_vpc,PTPL,trust_def_gw, nlb_vpc_cidr) == False:
                    logger.error('Config firewall NAT rule from panorama failed for ilb %s, ILB-port %d', dns_name, nlb_port)
                    set_nat = False
                    break
                

            if set_nat == True:
                # Find all the ilb deleted
                for rule_mask_index,item in enumerate(nlb_port_mask):
                    fw_rule_mask = long(fw['iLBRuleMask'+str(rule_mask_index)], 0)
                    if item & fw_rule_mask != fw_rule_mask:
                        #Found ILB entry has been deleted
                        for bit in range(0,64):
                            if (fw_rule_mask & 1<<bit) != 0 and (item & 1<<bit) == 0:
                                nlb_port = rule_mask_index*64+bit+start_nlb_port
                                if lib.config_firewall_delete_nat_rule_panorama(PIP,KeyPANWPanorama,PanoramaAdminUser,PDG,dns_name,nlb_port,trust_def_gw,PTPL) == False:
                                    logger.error('Delete firewall NAT rule from panorama failed for ilb %s, ILB-port %d', dns_name, nlb_port)                                     
                                    set_nat = False
                if lib.config_firewall_commit(fwcontext, fw['MgmtIP'], KeyPANWFirewall) == False:
                    logger.error('Commit firewall configuration failed for instance %s, IP %s', fw['InstanceID'], fw['MgmtIP'])
                else:
                    for mask in nlb_port_mask:
                        print('port mask committed in COMMIT: {}'.format(mask))
                    lib.firewall_table_update_rule_mask(stackname, region, fw['InstanceID'], nlb_port_mask)
                    lib.firewall_table_update_state(stackname, region, fw['InstanceID'], 'READY')
                    
            
    except Exception as e:
        logger.exception("Exception occurred while processing firewalls in commit: {}".format(e))

    # Retrieve message from ILB queue
    pre_port = -1
    fw_update = False
    for read in xrange(0, 10):
        try:
            logger.info('Calling to retrieve message from ILB queue..: {}'.format(NetworkLoadBalancerQueue))
            message_data_str, ts, rh = lib.get_from_ilb_queue(NetworkLoadBalancerQueue, 10, 0)
            if not message_data_str:
                logger.info('No message to retrieve from ILB queue.')
                break
            else:
                # Delete message from ILB queue
                lib.delete_message_from_queue(NetworkLoadBalancerQueue, rh)
                message_data = json.loads(message_data_str)
                logger.info("Data from sqs: {}".format(message_data_str))
                if 'MSG-TYPE' not in message_data or 'DNS-NAME' not in message_data:
                    logger.error("Found invalid message in InternalLoadBalancerQueue: {}".format(message_data_str))
                    continue
                nlb_type = message_data['MSG-TYPE']
                dns_name = message_data['DNS-NAME']
                if nlb_type == 'ADD-NLB':
                    nlb_vpc = message_data['VPC-ID']
                    nlb_name = message_data['NLB-NAME']
                    dns_name = message_data['DNS-NAME']
                    nlb_azs = message_data['AVAIL-ZONES']

                    vpc_endpoint_service_name = message_data['VPC-ENDPOINT-SERVICE-NAME']
                    vpc_peerconn_id = 'None'

                    # vpc_endpoint_service_name will be 'None' in same vpc case
                    if vpc_endpoint_service_name != 'None':
                        # Get the list of subnets that should have vpc endpoints in them
                        # Because of potential mismatch between # azs, we need to determine which subnets are in azs
                        response = ec2_client.describe_vpc_endpoint_services(ServiceNames=[vpc_endpoint_service_name])
                        potential_availability_zones = response['ServiceDetails'][0]['AvailabilityZones']
                        logger.info('ADD-NLB: endpoint service availability zones: {}'.format(potential_availability_zones))
                        # Get the availability zone of each fw trust subnet
                        response = ec2_client.describe_subnets(SubnetIds=subnettrust.split(','))
                        logger.info('ADD-NLB: trust subnets: {}'.format(response))
                        endpoint_subnets = []
                        for subnet in response['Subnets']:
                            if subnet['AvailabilityZone'] in potential_availability_zones:
                                endpoint_subnets.append(subnet['SubnetId'])

                        if endpoint_subnets:
                            response = ec2_client.create_vpc_endpoint(
                                VpcEndpointType='Interface',
                                VpcId=vpcid,
                                ServiceName=vpc_endpoint_service_name,
                                SubnetIds=endpoint_subnets,
                                SecurityGroupIds=[ sg_trust ]
                            )

                            logger.info('create_vpc_endpoint RESPONSE: {}'.format(response))
                            logger.info('create_vpc_endpoint DnsEntries: {}'.format(response['VpcEndpoint']['DnsEntries']))
                            try:
                                logger.info('create_vpc_endpoint Main DNS Entry: {}'.format(response['VpcEndpoint']['DnsEntries'][0]['DnsName']))
                                # Update dns_name variable with VPC Endpoint Interface address instead of ILB address
                                dns_name = response['VpcEndpoint']['DnsEntries'][0]['DnsName']
                            except:
                                logger.error("ADD-NLB: create_vpc_endpoint returned zero valid endpoint interfaces.")

                            # Overwrite nlb_vpc with hub VPC ID; routing rules will be same as same VPC case
                            nlb_vpc = vpcid
                        else:
                            logger.error("ADD-NLB: no subnets found overlapping the availability zones of endpoint service.")

                    # Look up VPC CIDR
                    response = ec2_client.describe_vpcs(VpcIds=[nlb_vpc])
                    for r in response['Vpcs']:
                        nlb_vpc_cidr= r['CidrBlock']

                    total_nlb_az = len(nlb_azs)
                    nlb_port = lib.nlb_table_get_next_avail_port(stackname, region)
                    for wait in xrange(0, 20):
                        if pre_port == nlb_port and pre_port != 0:
                            time.sleep(0.05)
                        else:
                            pre_port = nlb_port
                            break
                    if wait == 20:
                        logger.error("Get next available port returns the same port %d, skip adding nlb %s", nlb_port, nlb_name)
                        continue
                    else:
                        logger.info("Wait for syncing dynamodb sleep count %d", wait)

                    if nlb_port == 0:
                        logger.error("All ports number(%d-%d) has been used. Please deleting old network load balancer before adding more, skip adding nlb %s", 
                                    start_nlb_port, num_nlb_port + start_nlb_port - 1, nlb_name)
                        continue
                    # nlbtable dynamodb entry .
                    SubnetAzdata = [None] * 4
                    nlb_cidr_block = []
                    for index, item in enumerate(nlb_azs):
                        nlb_subnet_id = item['SUBNET-ID']
                        nlb_zone_name = item['ZONE-NAME']
                        nlb_subnet_cidr = item['SUBNET-CIDR']
                        nlb_cidr_block.append(nlb_subnet_cidr)
                        # join the variables nlb_subnet_id,nlb_zone_name,nlb_subnet_cidr
                        subnetazdata = nlb_subnet_id, nlb_subnet_cidr, nlb_zone_name
                        # make a list SubnetAzdata
                        SubnetAzdata[index] = ', '.join(subnetazdata)
                    
                    logger.info("Add ILB entry DNSname %s, Port %d in COMMIT state", dns_name, nlb_port)    
                    if lib.nlb_table_add_entry(stackname, region, nlb_port, 'COMMIT', SubnetAzdata[0], SubnetAzdata[1], SubnetAzdata[2], SubnetAzdata[3], dns_name, nlb_name,vpc_peerconn_id, nlb_vpc, nlb_vpc_cidr) == False :
                        logger.error("Failed to add ILB entry DNSname %s, Port %d in COMMIT state", dns_name, nlb_port)
                        break

                    #Add NAT rules on firewall via panorama
                         
                    logger.info('Config firewall NAT rule from panorama')
                    fw_update = True
                    if lib.config_firewall_add_nat_rule_panorama(PIP,KeyPANWPanorama,PanoramaAdminUser,PDG,dns_name,nlb_port,nlb_vpc,PTPL,trust_def_gw,nlb_vpc_cidr) == False:
                        logger.error('Config firewall NAT rule from panorama failed for ilb %s, ILB-port %d', dns_name, nlb_port)
                        break
                    #    lib.firewall_table_update_state(stackname, region, fw['InstanceID'], 'COMMIT')



                elif nlb_type == 'ADD-ALB':
                    nlb_vpc = message_data['VPC-ID']
                    nlb_vpc_cidr = message_data['VPC-CIDR']
                    nlb_name = message_data['ALB-NAME']
                    dns_name = message_data['DNS-NAME']
                    nlb_azs = message_data['AVAIL-ZONES']
                    vpc_peerconn_id = message_data['VPC-PEERCONN-ID']
                    total_nlb_az = len(nlb_azs)
                    nlb_port = lib.nlb_table_get_next_avail_port(stackname, region)
                    for wait in xrange(0, 20):
                        if pre_port == nlb_port and pre_port != 0:
                            time.sleep(0.05)
                        else:
                            pre_port = nlb_port
                            break
                    if wait == 20:
                        logger.error("Get next available port returns the same port %d, skip adding alb %s", nlb_port, nlb_name)
                        continue
                    else:
                        logger.info("Wait for syncing dynamodb sleep count %d", wait)
  
                    if nlb_port == 0:
                        logger.error("All ports number(%d-%d) has been used. Please deleting old network load balancer before adding more, skip adding nlb %s", 
                                    start_nlb_port, num_nlb_port+start_nlb_port-1, nlb_name)
                        continue
                    
                    #nlbtable dynamodb entry .
                    SubnetAzdata = [None] * 4
                    nlb_cidr_block = []
                    for index,item in enumerate(nlb_azs):
                        nlb_subnet_id = item['SUBNET-ID']
                        nlb_zone_name = item['ZONE-NAME']
                        nlb_subnet_cidr = item['SUBNET-CIDR']
                        nlb_cidr_block.append(nlb_subnet_cidr)
                        #join the variables nlb_subnet_id,nlb_zone_name,nlb_subnet_cidr
                        subnetazdata = nlb_subnet_id,nlb_subnet_cidr,nlb_zone_name
                        #make a list SubnetAzdata
                        SubnetAzdata[index] =  ', '.join(subnetazdata)
                    
                    logger.info("Add ILB entry DNSname %s, Port %d in COMMIT state", dns_name, nlb_port)
                    if lib.nlb_table_add_entry(stackname, region, nlb_port, 'COMMIT', SubnetAzdata[0], SubnetAzdata[1], SubnetAzdata[2], SubnetAzdata[3], dns_name, nlb_name,vpc_peerconn_id, nlb_vpc, nlb_vpc_cidr) == False :
                        logger.error("Failed to add ILB entry DNSname %s, Port %d in COMMIT state", dns_name, nlb_port)
                        break                    
                                                 
                            

                    #Add NAT rules on firewall via panorama
                         
                    logger.info('Config firewall NAT rule from panorama')
                    fw_update = True
                    if lib.config_firewall_add_nat_rule_panorama(PIP,KeyPANWPanorama,PanoramaAdminUser,PDG,dns_name,nlb_port,nlb_vpc,PTPL,trust_def_gw,nlb_vpc_cidr) == False:
                        logger.error('Config firewall NAT rule from panorama failed for ilb %s, ILB-port %d', dns_name, nlb_port)
                        break
                    #    lib.firewall_table_update_state(stackname, region, fw['InstanceID'], 'COMMIT')
                    
                    #VPC-peering
                    if vpc_peerconn_id == "None":
                        logger.error('VPC peering connection id not found; cannot add routes to routetable')
                    elif vpcid == nlb_vpc:
                        logger.error('ILB is deployed in the same VPC as ELB , no vpc peering needed')                        
                    else:
                        logger.info('ILB is deployed in a seperate VPC than ELB - Accept the VPC peer request')
                        #vpc_peering_connection = ec2.accept_vpc_peering_connection(vpc_peerconn_id)
                        logger.info('Proceed to create route table entries for vpc peer')
                        routetableid = routetableidtrust.split(',')
                        for i in range (len(nlb_cidr_block)):
                            for j in range (len(routetableid)):
                                DestinationCidrBlock = nlb_cidr_block[i]
                                RouteTableId = routetableid[j]
                                VpcPeeringConnectionId = vpc_peerconn_id                               
                                if create_vpcpeer_routetable_entry(DestinationCidrBlock,RouteTableId,VpcPeeringConnectionId) == False:
                                    logger.error('Could not add route entries to table')
                                    #print(error_line)
                               

                elif nlb_type == 'DEL-NLB':
                    #Deleting all entries belong to same DNSName

                    vpc_endpoint_service_name = message_data['VPC-ENDPOINT-SERVICE-NAME']
                    if vpc_endpoint_service_name != 'None':
                        # If cross vpc, we need to delete any vpc endpoint interfaces

                        # Get a list of all endpoints that connect to the NLB endpoint service
                        response = ec2_client.describe_vpc_endpoints(Filters=[{
                            'Name': 'service-name',
                            'Values': [vpc_endpoint_service_name]
                        }])

                        # Update dns_name with VPC Endpoint Interface DNS name
                        try:
                            dns_name = response['VpcEndpoints'][0]['DnsEntries'][0]['DnsName']
                        except:
                            logger.error("Unable to retrieve DNS name for endpoint interface connected to service %s", vpc_endpoint_service_name)
                            continue

                        # Convert the list of endpoint objects to a list of endpoint id strings
                        endpoint_ids = map(lambda endpoint: endpoint['VpcEndpointId'], response['VpcEndpoints'])
                        logger.info('[DEL-NLB] Removing vpc endpoints: {}'.format(endpoint_ids))

                        # Delete all endpoints connected to the NLB endpoint service
                        response = ec2_client.delete_vpc_endpoints(VpcEndpointIds=endpoint_ids)


                    print('Receive DEL-NLB msg from ilb queue')
                    response = lib.nlb_table_get_entry_by_dnsname(stackname, region, dns_name)
                    
                    if response['Count'] == 0:
                        logger.error("Receive NLB msg to delete non-existing NLB. DNS Name: %s", dns_name)
                        continue
                    for nlb in response['Items']:
                        nlb_port = nlb['TCPPort']
                        
                        #Delete Nat entries
                        logger.info('Delete firewall NAT rule from panorama')
                        fw_update = True
                        if lib.config_firewall_delete_nat_rule_panorama(PIP,KeyPANWPanorama,PanoramaAdminUser,PDG,dns_name,nlb_port,trust_def_gw,PTPL) == False:
                            logger.error('Delete firewall NAT rule from panorama failed for ilb %s, NLB-port %d', dns_name, nlb_port)  

                    #Delete nlb table entry for this specific nlb.
                    lib.nlb_table_delete_entry_by_dnsname(stackname, region, dns_name) 
                    
                elif nlb_type == 'DEL-ALB':
                    #Deleting all entries belong to same DNSName

                    print('Received DEL-ALB msg from ilb queue')
                    response = lib.nlb_table_get_entry_by_dnsname(stackname, region, dns_name)
                    
                    if response['Count'] == 0:
                        logger.error("Receive ALB msg to delete non-existing ALB. DNS Name: %s", dns_name)
                        continue
                    for nlb in response['Items']:
                        nlb_port = nlb['TCPPort']
                        vpc_peerconn_id = nlb['VPCPeerConnID']
                        nlb_vpc = nlb['VPCID']
                    	if vpc_peerconn_id == "None":
                        	logger.error('VPC peering connection id not found.')
                        elif vpcid == nlb_vpc:
                        	logger.error('ILB is deployed in the same VPC as ELB , no vpc peering to be deleted')                        
                    	else:
                    	    #Remove vpcpeering routes from routetables.                        
                            Subnetcidraz1 = nlb['Subnet-CIDR-AZ1']
                            Subnetcidraz2 = nlb['Subnet-CIDR-AZ2']
                            Subnetcidraz3 = nlb['Subnet-CIDR-AZ3']
                            Subnetcidraz4 = nlb['Subnet-CIDR-AZ4']
                            #nlb_cidr_block = [None] * 4
                            nlb_cidr_block = []
                            nlb_subnet1, nlb_cidr1, az1 = Subnetcidraz1.split(',')
                            nlb_cidr_block.append(nlb_cidr1)
                            nlb_subnet2, nlb_cidr2, az2 = Subnetcidraz2.split(',')
                            nlb_cidr_block.append(nlb_cidr2)
                            if Subnetcidraz3:
                                nlb_subnet3, nlb_cidr3, az3 = Subnetcidraz3.split(',')
                                nlb_cidr_block.append(nlb_cidr3)
                            if Subnetcidraz4:
                                nlb_subnet4, nlb_cid4, az4 = Subnetcidraz4.split(',')
                                nlb_cidr_block.append(nlb_cidr4)
                            print("[{0}]".format(', '.join(map(str, nlb_cidr_block))))
                            logger.info('Delete route table entries for vpc peer')
                            routetableid = routetableidtrust.split(',')
                            for i in range (len(nlb_cidr_block)):
                                for j in range (len(routetableid)):
                                    DestinationCidrBlock = nlb_cidr_block[i]
                                    RouteTableId = routetableid[j]
                                    if delete_vpcpeer_routetable_entry(DestinationCidrBlock,RouteTableId) == False:
                                        print(error_line)
                       
                        #Delete Nat entries  
                        logger.info('Delete firewall NAT rule from panorama')
                        fw_update = True
                        if lib.config_firewall_delete_nat_rule_panorama(PIP,KeyPANWPanorama,PanoramaAdminUser,PDG,dns_name,nlb_port,trust_def_gw,PTPL) == False:
                            logger.error('Delete firewall NAT rule from panorama failed for ilb %s, ILB-port %d', dns_name, nlb_port)   

                        #Delete nlb table entry for this specific nlb.
                        lib.nlb_table_delete_entry_by_dnsname(stackname, region, dns_name)
                        logger.info('Delete ilb table entry for this specific ilb %s, ILB-port %d', dns_name, nlb_port)

                else:
                    logger.error('Receive invalid ILB message type for Internal load balancer queue')

        except Exception as e:
            logger.exception("Exception occurred while retrieving data from ILB queue: {}".format(e))
   
    # Perform commit once for all firewalls in READY state
    if fw_update == True:
        try:
            nlb_port_mask = []
            for i in range (0, (num_nlb_port)/64):
                 nlb_port_mask.append(0)

            # Find all the ilb in commit state
            nlb_response=lib.nlb_table_get_all_in_state(stackname, region, 'COMMIT')
            print('ilb_response count: {}'.format(nlb_response['Count']))

            for nlb in nlb_response['Items']:
                nlb_port = nlb['TCPPort']
                rule_mask_index = int((nlb_port-start_nlb_port)/64)
                nlb_bit = int((nlb_port-start_nlb_port)%64)
                nlb_port_mask[rule_mask_index] |= 1<<nlb_bit

            response=lib.firewall_table_get_all_in_state(stackname, region, 'READY')
            for fw in response['Items']:
                if lib.config_firewall_commit(fwcontext, fw['MgmtIP'], KeyPANWFirewall) == False:
                    logger.error('Commit firewall configuration failed for instance %s, IP %s', fw['InstanceID'], fw['MgmtIP'])
                    lib.firewall_table_update_state(stackname, region, fw['InstanceID'], 'COMMIT')
                else:
                    for mask in nlb_port_mask:
                        print('port mask commited in READY: {}'.format(mask))

                    lib.firewall_table_update_rule_mask(stackname, region, fw['InstanceID'], nlb_port_mask)
        except Exception as e:
            logger.exception("Exception occurred while updating firewall rules: {}".format(e))

 
    print("Time remaining return internal_load_balancer_update (MS):", context.get_remaining_time_in_millis())

def firewall_init_config(event, context):
    """
    Method to monitor the firewall of INIT state in firewall table and set state
    to COMMIT if firewall auto commit completes

    :param event: Encodes all the input variables to the lambda function, when
                  the function is invoked.
                  Essentially AWS Lambda uses this parameter to pass in event
                  data to the handler function.
    :type event: dict

    :param context: AWS Lambda uses this parameter to provide runtime information to your handler.
    :type context: LambdaContext

    :return: None
    """
    print("firewall_init_config Time remaining (MS):", context.get_remaining_time_in_millis())   
    
    #Get all firewall instance in INIT state
    response=lib.firewall_table_get_all_in_state(stackname, region, 'INIT')
    for fw in response['Items']:
        try:
            logger.info("Fireawall in init state: {}".format(fw))
            # Need this to by pass invalid certificate issue.
            fwcontext = lib.get_ssl_context()
    
            if lib.is_firewall_ready(fwcontext, fw['MgmtIP'],KeyPANWFirewall) == False:
                logger.info('Firewall is not in ready state yet')
                lib.is_firewall_auto_commit_done(fwcontext, fw['MgmtIP'],KeyPANWFirewall)
            else:
                serial_no = lib.get_device_serial_no(fwcontext, fw['InstanceID'], fw['MgmtIP'], KeyPANWFirewall)
                if not serial_no:
                    logger.error('Failed to retrieve serial_no from fw')
                elif not lib.firewall_table_update_serial_no(stack_name=stackname, region=region, instance_id=fw['InstanceID'], serial_no=serial_no):
                    logger.error('Failed to update fw table with serial no')

                # Setup awscloudwatch to asg
                if lib.config_firewall_init_setting_panorama(PIP,KeyPANWPanorama,PanoramaAdminUser,fw['AsgName'],PTPL,PDG) == False:
                    logger.error('Config firewall init setting failed')    
                else:
                    lib.firewall_table_update_state(stackname, region, fw['InstanceID'], 'COMMIT')
            #Workaround for the panorama bug : PAN-94559- commit force implemented in the below call.
            #if lib.initial_push_to_device_panorama(PIP,KeyPANWPanorama,PTPL,com_force) == False:
            	#logger.info("Initial push did not go through on panorama")
            #else:
            #	logger.info("panorama should pushed initial configuration  to devices that got registered to the DG")
        except Exception as e:
            logger.exception("Exception occurred while checking if firewall is ready: {}".format(e))

    print("Time remaining return firewall_init_config (MS):", context.get_remaining_time_in_millis())

def delete_vpcpeer_routetable_entry(DestinationCidrBlock,RouteTableId):
    """
    Method to delete vpc peer routes to trust routng table 

    :param DestinationCidrBlock
    :param RouteTableId

    """
    logger.info('Deleting route table entries for Dst CIDR in route table :{}, {}'.format(DestinationCidrBlock, RouteTableId))
    try:
        response = ec2_client.delete_route(DestinationCidrBlock=DestinationCidrBlock,
                                           RouteTableId=RouteTableId)
    except Exception:
        logger.exception("Deleting routes to route table failed for dst CIDR:" + DestinationCidrBlock)

def create_vpcpeer_routetable_entry(DestinationCidrBlock,RouteTableId,VpcPeeringConnectionId):
    """
    Method to add vpc peer routes to trust routng table 

    :param DestinationCidrBlock
    :param RouteTableId
    :param VpcPeeringConnectionId

    """
    logger.info('Creating route table entries for Dst CIDR in route table :{}, {}'.format(DestinationCidrBlock, RouteTableId))
    try:
        response = ec2_client.create_route(DestinationCidrBlock=DestinationCidrBlock,
                                           RouteTableId=RouteTableId,
                                           VpcPeeringConnectionId=VpcPeeringConnectionId)
    except Exception:
        logger.exception("Adding routes to route table failed for dst CIDR:" + DestinationCidrBlock)
        
def lambda_handler(event, context):
    """
    .. note:: This function is the entry point for the ```sched_event1``` Lambda function.

    This function performs the following actions:
    firewall_asg_update(event, context)
    firewall_init_config(event, context)
    network_load_balancer_update(event, context)

        | invokes ```check_and_send_message_to_queue()```
        |  desc: Checks the messages on the queue to ensure its up to date
        |        and for any changes as the case maybe.

        | invokes ```firewall_asg_update()```
        |  desc: monitor firewall asg and create asg if not exist

        | invokes ```firewall_init_config()```
        |  desc: monitor firewall in INIT state and move it to COMMIT if 
        |        firewall auto commit is done

        | invokes ```network_load_balancer_update()```
        |  desc: update firewall nat rules based on info in firewall table
        |        nlb table

    :param event: Encodes all the input variables to the lambda function, when
                  the function is invoked.
                  Essentially AWS Lambda uses this parameter to pass in event
                  data to the handler function.
    :type event: dict

    :param context: AWS Lambda uses this parameter to provide runtime information to your handler.
    :type context: LambdaContext

    :return: None
    """
    global stackname
    global ilb_tag
    global elb_name
    global ELBTargetGroupName 
    global region
    global sg_mgmt
    global sg_untrust
    global sg_trust
    global sg_vpc
    global keyname
    global iamprofilebs
    global s3master
    global subnetmgmt
    global subnetuntrust
    global subnettrust
    global routetableidtrust
    global vpcid    
    global imageID
    global ScalingPeriod
    global ScaleUpThreshold
    global ScaleDownThreshold
    global ScalingParameter
    global instanceType
    global gcontext
    global MinInstancesASG
    global MaximumInstancesASG
    global LambdaExecutionRole
    global LambdaENISNSTopic
    global ASGNotifierRolePolicy
    global ASGNotifierRole
    global LambdaS3Bucket
    global PanS3KeyTpl
    global KeyPANWFirewall
    global KeyPANWPanorama
    global PanoramaAdminUser
    global SubnetIDNATGW
    global SubnetIDLambda
    global PIP
    global PDG
    global PTPL
    global Hostname
    global logger
    global LambdaENIQueue
    global NetworkLoadBalancerQueue 
    global fw_azs
    global trust_def_gw 

    gcontext = context
    #print("First operation remaining (MS):", context.get_remaining_time_in_millis())
    #print('Parameters {}...'.format(event))
    
    stackname=event['StackName']
    elb_name=event['ELBName']
    ELBTargetGroupName=event['ELBTargetGroupName']
    sg_mgmt=event['MgmtSecurityGroup']
    sg_trust=event['TrustSecurityGroup']
    sg_untrust=event['UntrustSecurityGroup']
    sg_vpc=event['VPCSecurityGroup']
    keyname=event['KeyName']
    s3master=event['BootstrapS3Bucket']
    subnetmgmt=event['SubnetIDMgmt']
    subnettrust=event['SubnetIDTrust']
    routetableidtrust=event['RouteTableIDTrust']
    vpcid = event['VpcId']     
    subnetuntrust=event['SubnetIDUntrust']
    imageID=event['ImageID']
    instanceType=event['FWInstanceType']
    region=event['Region']
    iamprofilebs=str(event['FirewallBootstrapRole'])
    LambdaENISNSTopic=str(event['LambdaENISNSTopic'])
    LambdaExecutionRole=str(event['LambdaExecutionRole'])
    ASGNotifierRole=str(event['ASGNotifierRole'])
    ASGNotifierRolePolicy=str(event['ASGNotifierRolePolicy'])
    LambdaS3Bucket=event['LambdaS3Bucket']
    PanS3KeyTpl=event['PanS3KeyTpl']
    KeyPANWFirewall=event['KeyPANWFirewall']
    KeyPANWPanorama=event['KeyPANWPanorama']
    PanoramaAdminUser=event['PanoramaAdminUser']
    SubnetIDNATGW=event['SubnetIDNATGW']
    SubnetIDLambda=event['SubnetIDLambda']
    PIP=event['PIP']
    PDG=event['PDG']
    PTPL=event['PTPL']
    Hostname=event['Hostname']
    LambdaENIQueue=event['LambdaENIQueue']
    NetworkLoadBalancerQueue=event['NetworkLoadBalancerQueue']

    logger = logging.getLogger()

    debug = event['Debug']
    if debug == 'Yes':
        logger.setLevel(logging.INFO)

    logger.info('got event{}'.format(event))

    subnetuntrust=str(lib.fix_unicode(subnetuntrust))
    subnetuntrust=lib.fix_subnets(subnetuntrust)
    
    subnetmgmt=str(lib.fix_unicode(subnetmgmt))
    subnetmgmt=lib.fix_subnets(subnetmgmt)
    
    subnettrust=str(lib.fix_unicode(subnettrust))
    subnettrust=lib.fix_subnets(subnettrust)

    SubnetIDNATGW=str(lib.fix_unicode(SubnetIDNATGW))
    SubnetIDNATGW=lib.fix_subnets(SubnetIDNATGW)

    SubnetIDLambda=str(lib.fix_unicode(SubnetIDLambda))
    SubnetIDLambda=lib.fix_subnets(SubnetIDLambda)

    routetableidtrust=str(lib.fix_unicode(routetableidtrust))
    routetableidtrust=lib.fix_subnets(routetableidtrust)    
    
    logger.info('StackName:' +  event['StackName'])
    logger.info('ELB Name: ' + elb_name)
    logger.info('Mgmt Security Group ID : ' + sg_mgmt)
    logger.info('KeyName is :' + keyname)
    logger.info('S3 Master Bucket :' + s3master)
    logger.info('iamprofilebs: ' + iamprofilebs)
    logger.info('Subnet Mgmt List: ' + subnetmgmt)
    logger.info('Subnet Untrust List: ' + subnetuntrust)
    logger.info('Subnet Trust List: ' + subnettrust)
    logger.info('Trust Route Table IDlist: ' + routetableidtrust)
    logger.info ('Deployed VpcId is :' + vpcid)     
    if PIP != "":
        logger.info('Panorama IP is: ' + PIP)

    ScalingPeriod = int(event['ScalingPeriod'])
    ScaleUpThreshold = float(event['ScaleUpThreshold'])
    ScaleDownThreshold = float(event['ScaleDownThreshold'])
    ScalingParameter = event['ScalingParameter']
    MinInstancesASG = int(event['MinInstancesASG'])
    MaximumInstancesASG = int(event['MaximumInstancesASG']) 

    stack_metadata= {
                'SGM': sg_mgmt, 'SGU': sg_untrust, 'SGT': sg_trust, 'SGV': sg_vpc,
                'IamLambda': LambdaExecutionRole, 'StackName': stackname, 'Region': region,
                'LambdaS3Bucket': LambdaS3Bucket, 'PanS3KeyTpl': PanS3KeyTpl, 
                'ScalingParameter': ScalingParameter, 'SubnetIDNATGW': SubnetIDNATGW, 
                'PIP': PIP, 'PDG': PDG, 'PTPL': PTPL, 'Hostname': Hostname, "Debug":debug
               }

    check_and_send_message_to_queue(LambdaENIQueue, json.dumps(stack_metadata))

    logger.info('First Time remaining (MS):' + str(context.get_remaining_time_in_millis()))

    try:
        fw_azs = lib.getAzs(subnettrust)
        #print("[{0}]".format(', '.join(map(str, fw_azs))))
        trust_def_gw = []
        for i in fw_azs:
            #logger.info("got inside of for loop")
            trust_subnet_id=lib.choose_subnet(subnettrust, i)
            subnet=ec2.Subnet(trust_subnet_id)
            subnet_str,gw=lib.get_subnet_and_gw(subnet.cidr_block)
            trust_def_gw.append(gw)
            #logger.info("Trust subnet default gw[{}]: {}".format(i, trust_def_gw[i]))
        logger.info("trust_def_gw:")
        print("[{0}]".format(', '.join(map(str, trust_def_gw))))    
    except Exception as e:
        logger.exception("Get az and trust default gw error]: {}".format(e))

    firewall_asg_update(event, context)
    firewall_init_config(event, context)
    network_load_balancer_update(event, context)
        
    logger.info('DONE: Last Operations: Time remaining (MS):' + str(context.get_remaining_time_in_millis()))
