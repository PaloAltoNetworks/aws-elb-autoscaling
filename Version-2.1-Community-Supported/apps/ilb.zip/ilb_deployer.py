import boto3
import httplib
import json
import logging
from urlparse import urlparse
from contextlib import closing

events_client = boto3.client('events')
iam = boto3.client('iam')
lambda_client = boto3.client('lambda')
logger = logging.getLogger()
logger.setLevel(logging.INFO)


lb_client = boto3.client('elbv2')
sqs_client = boto3.client('sqs')
sts_client = boto3.client('sts')
ec2_client = boto3.client('ec2')
sts_client = boto3.client('sts')


def get_vpc_endpoint_service_name(vpc_endpoint_service_id):
    """
    Queries aws for the ServiceName attribute of the given vpc endpoint

    Makes a call to describe_vpc_endpoint_services and loops through to find the
    name which contains the given vpc endpoint service id
    """
    response = ec2_client.describe_vpc_endpoint_services()
    names = response['ServiceNames']
    for name in names:
        if vpc_endpoint_service_id in name:
            logger.info('Found vpc endpoint service name: {} for id: {}'.format(name, vpc_endpoint_service_id))
            return name
    logger.error('No vpc endpoint service names match the id: {}'.format(vpc_endpoint_service_id))


def create_vpcpeer_routetable_entry(DestinationCidrBlock, RouteTableId, VpcPeeringConnectionId):
    """
    Method to add vpc peer routes to trust routng table

    :param DestinationCidrBlock
    :param RouteTableId
    :param VpcPeeringConnectionId
    :return: None
    """
    logger.info('Creating route table entries for Dst CIDR in route table :{}, {}'.format(DestinationCidrBlock, RouteTableId))
    try:
        response = ec2_client.create_route(DestinationCidrBlock=DestinationCidrBlock,
                                           RouteTableId=RouteTableId,
                                           VpcPeeringConnectionId=VpcPeeringConnectionId)
        logger.info('[create_vpcpeer_routetable_entry] RESPONSE: {}'.format(response))
    except Exception:
        logger.exception("Adding routes to route table failed for dst CIDR:" + DestinationCidrBlock)


def delete_vpcpeer_routetable_entry(DestinationCidrBlock, RouteTableId):
    """
    Method to delete vpc peer routes to trust routng table

    :param DestinationCidrBlock
    :param RouteTableId
    :param VpcPeeringConnectionId
    :return: None
    """
    logger.info('Deleting route table entries for Dst CIDR in route table: {}, {}'.format(DestinationCidrBlock, RouteTableId))
    try:
        response = ec2_client.delete_route(DestinationCidrBlock=DestinationCidrBlock,
                                           RouteTableId=RouteTableId)
        logger.info('[delete_vpcpeer_routetable_entry] RESPONSE: {}'.format(response))
    except Exception:
        logger.exception('Deleting routes from route table failed for dst CIDR: {}'.format(DestinationCidrBlock))


def get_subnet_info(az_info):
    """
    Method to get information on all subnets in an AZ

    :param az_info:
    :return subnet data:
    """
    print("Az info: {}".format(az_info))
    subnet_ids = list(map(lambda az: az['SUBNET-ID'], az_info))
    subnet_data = ec2_client.describe_subnets(
        SubnetIds=subnet_ids
    )
    print("Subnet data: {}".format(subnet_data))
    return subnet_data


def send_to_queue(data, queue_url, _sts_sqs_client):
    """
    Method to push the DNS Names of the ILB into a SQS Queue
    :param dns_name:
    :return:
    """

    if _sts_sqs_client:
        logger.info("[assumed role sqs resource]: Sending data to queue")

        _sts_sqs_client.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(data),
            MessageAttributes={
                'panw-fw-nlb-msg': {
                    'StringValue': '1000',
                    'DataType': 'String'
                }
            }
        )
    else:
        logger.info("[send_to_queue]: Final data being sent to queue: {}".format(data))
        sqs_client.send_message(
            QueueUrl=queue_url,
            MessageBody=json.dumps(data),
            MessageAttributes={
                'panw-fw-nlb-msg': {
                    'StringValue': '1000',
                    'DataType': 'String'
                }
            }
        )


def assume_role_and_send_to_queue(role_arn, data, queue_url):
    """

    :param data:
    :return:
    """

    assumedRoleObject = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName="AssumeRoleSession1"
    )

    # From the response that contains the assumed role, get the temporary
    # credentials that can be used to make subsequent API calls
    credentials = assumedRoleObject['Credentials']

    sqs_resource = boto3.client(
        'sqs',
        aws_access_key_id=credentials['AccessKeyId'],
        aws_secret_access_key=credentials['SecretAccessKey'],
        aws_session_token=credentials['SessionToken']
    )

    send_to_queue(data, queue_url, sqs_resource)


def modify_message_data(az_info):
    """
    Changes the az_info object keys from SubnetId to SUBNET-ID and ZoneName to ZONE-NAME

    :param az_info:
    :return:
    """

    logger.info("[modify_message_data]: Input az_info: {}".format(az_info))
    try:
        az_data = []
        for _az in az_info:
            subnet_id = _az.pop('SubnetId')
            zone_name = _az.pop('ZoneName')

            _az['SUBNET-ID'] = subnet_id
            _az['ZONE-NAME'] = zone_name
            az_data.append(_az)

        logger.info("[modify_message_data] Modified message data: {}".format(az_data))
        return az_data
    except Exception, e:
        logger.info(e)
    logger.info("Returning from modify_message_data")
    return None


def parse_and_create_del_alb_data(ilb_response):
    return {
        'MSG-TYPE': 'DEL-ALB',
        'DNS-NAME': ilb_response
    }


def parse_and_create_del_nlb_data(ilb_response, vpc_endpoint_service_name):
    return {
        'MSG-TYPE': 'DEL-NLB',
        'DNS-NAME': ilb_response,
        'VPC-ENDPOINT-SERVICE-NAME': vpc_endpoint_service_name
    }


def parse_and_create_add_nlb_data(ilb_response, vpc_endpoint_service_name):
    """
    Example Message:
    {
      "AVAIL-ZONES": [
        {
          "LoadBalancerAddresses": [
            {}
          ],
          "SUBNET-CIDR": "172.32.0.0/24",
          "SUBNET-ID": "subnet-0b901425",
          "ZONE-NAME": "us-east-1a"
        },
        {
          "LoadBalancerAddresses": [
            {}
          ],
          "SUBNET-CIDR": "172.32.1.0/24",
          "SUBNET-ID": "subnet-4a5a1300",
          "ZONE-NAME": "us-east-1b"
        }
      ],
      "MSG-TYPE": "ADD-NLB",
      "DNS-NAME": "prot-ilb-b7aaa076742392b2.elb.us-east-1.amazonaws.com",
      "NLB-NAME": "prot-ilb",
      "NLB-ARN": "arn:aws:elasticloadbalancing:us-east-1:441384421500:loadbalancer/net/prot-ilb/b7aaa076742392b2",
      "VPC-ENDPOINT-SERVICE-ID": "vpce-svc-0e3558640fb9b6d57",
      "VPC-ID": "vpc-c173b8bb"
    }
    """
    load_balancers = ilb_response.get('LoadBalancers')
    if len(load_balancers) == 0:
        logger.error('[parse_and_create_add_nlb_data]: No load balancers found in ilb_response\n{}'.format(ilb_response))
        return {}
    ilb = load_balancers[0]
    dns_name = ilb.get('DNSName', None)
    ilb_name = ilb.get('LoadBalancerName')
    az_info = ilb.get('AvailabilityZones')

    logger.info("[parse_and_create_add_nlb_data]: Original AZ data: {}".format(az_info))
    updated_az_data = modify_message_data(az_info)
    logger.info("[parse_and_create_add_nlb_data]: Updated AZ data: {}".format(updated_az_data))

    subnets = get_subnet_info(updated_az_data)['Subnets']

    # Add vpc subnet cidrs to az info
    for az in updated_az_data:
        for subnet in subnets:
            if subnet['SubnetId'] == az['SUBNET-ID']:
                az['SUBNET-CIDR'] = subnet['CidrBlock']
                logger.info('[parse_and_create_add_nlb_data] Adding SUBNET-CIDR {} to AVAIL-ZONES'.format(subnet['CidrBlock']))

    vpc_id = ilb.get('VpcId', None)
    ilb_arn = ilb.get('LoadBalancerArn', None)
    msg_data = {
        'MSG-TYPE': 'ADD-NLB',
        'AVAIL-ZONES': updated_az_data,
        'DNS-NAME': dns_name,
        'VPC-ID': vpc_id,
        'VPC-ENDPOINT-SERVICE-NAME': vpc_endpoint_service_name,
        'NLB-NAME': ilb_name,
        'NLB-ARN': ilb_arn
    }
    return msg_data


def parse_and_create_add_alb_data(ilb_response, vpc_peer_connection):
    """
    Constructs an ADD-ALB message to send to the SQS queue. 
    If not cross vpc, vpc_peer_connection should be the string "None"


    """
    load_balancers = ilb_response.get('LoadBalancers')
    if len(load_balancers) == 0:
        logger.error('[parse_and_create_add_alb_data]: No load balancers found in ilb_response\n{}'.format(ilb_response))
        return {}
    ilb = load_balancers[0]
    dns_name = ilb.get('DNSName', None)
    ilb_name = ilb.get('LoadBalancerName')
    az_info = ilb.get('AvailabilityZones')

    logger.info("[parse_and_create_add_alb_data]: Original AZ data: {}".format(az_info))
    updated_az_data = modify_message_data(az_info)
    logger.info("[parse_and_create_add_alb_data]: Updated AZ data: {}".format(updated_az_data))

    subnets = get_subnet_info(updated_az_data)['Subnets']

    # Add vpc subnet cidrs to az info
    for az in updated_az_data:
        for subnet in subnets:
            if subnet['SubnetId'] == az['SUBNET-ID']:
                az['SUBNET-CIDR'] = subnet['CidrBlock']
                logger.info('[parse_and_create_add_alb_data] Adding SUBNET-CIDR {} to AVAIL-ZONES'.format(subnet['CidrBlock']))

    vpc_id = ilb.get('VpcId', None)

    # Retrieve the VPC CIDR and pass it; in the cross account case, we cannot look up the CIDR in the hub.
    response = ec2_client.describe_vpcs(VpcIds=[vpc_id])
    for r in response['Vpcs']:
        vpc_cidr= r['CidrBlock']

    ilb_arn = ilb.get('LoadBalancerArn', None)
    msg_data = {
        'MSG-TYPE': 'ADD-ALB',
        'AVAIL-ZONES': updated_az_data,
        'DNS-NAME': dns_name,
        'VPC-ID': vpc_id,
        'VPC-CIDR': vpc_cidr,
        'VPC-PEERCONN-ID': vpc_peer_connection,
        'ALB-NAME': ilb_name,
        'ALB-ARN': ilb_arn
    }
    return msg_data


def parse_and_create_ilb_data(msg_operation, ilb_response, vpc_peer_connection, vpc_endpoint_service_name, initial):
    """
    Constructs messages to send to the SQS queue

    :param msg_operation:
    :param ilb_response:
    :param vpc_peer_connection:
    :param initial:
    """

    msg_data = None

    if msg_operation == 'DEL-NLB':
        logger.info('[parse_and_create_ilb_data] Creating DEL-NLB message')
        msg_data = parse_and_create_del_nlb_data(ilb_response, vpc_endpoint_service_name)
    elif msg_operation == 'DEL-ALB':
        logger.info('[parse_and_create_ilb_data] Creating DEL-ALB message')
        msg_data = parse_and_create_del_alb_data(ilb_response)
    elif msg_operation == 'ADD-NLB':
        logger.info('[parse_and_create_ilb_data] Creating ADD-NLB message')
        msg_data = parse_and_create_add_nlb_data(ilb_response, vpc_endpoint_service_name)
    elif msg_operation == 'ADD-ALB':
        logger.info('[parse_and_create_ilb_data] Creating ADD-ALB message')
        msg_data = parse_and_create_add_alb_data(ilb_response, vpc_peer_connection)

    logger.info("[parse_and_create_ilb_data] Message to send to queue: {}".format(msg_data))
    return msg_data


def handle_ilb_delete(ilb_dns, ilb_type, queue_url, role_arn, vpc_endpoint_service_name):
    """
    This method handles the delete workflow
    associated with the case when an ILB has
    been deleted.

    This method performs the following actions:
    1. Extract ILB information from the DB.
    2. Construct and send a NLB-DEL/ALB-DEL message to SQS.

    :param ilb_arn:
    :return:
    """

    delete_message = parse_and_create_ilb_data(msg_operation='DEL-{}'.format(ilb_type),
                                               ilb_response=ilb_dns,
                                               vpc_peer_connection=None,
                                               vpc_endpoint_service_name=vpc_endpoint_service_name,
                                               initial=False)
    if role_arn:
        logger.info('[handle_ilb_delete] Role ARN specified. Calling handle_')
        assume_role_and_send_to_queue(role_arn, delete_message, queue_url)
    else:
        logger.info('[handle_ilb_delete] Send to queue in same account.')
        send_to_queue(delete_message, queue_url, None)


def handle_ilb_add(ilb_response,
                   ilb_type,
                   is_cross_vpc,
                   vpc_peer_connection,
                   vpc_endpoint_service_name,
                   ilb_route_table,
                   queue_url,
                   role_arn):
    """
    This method handles the add ilb workflow
    to identify a new ILB and publish the information
    out to a queue.

    :param ilb_arn:
    :param ilb_name:
    :return:
    """
    logger.info("****************** handle ilb add  START **************")
    logger.info("[handle_ilb_add] ILB details: {}".format(ilb_response))

    logger.info("Retrieve subnet details")

    add_message = parse_and_create_ilb_data(msg_operation='ADD-{}'.format(ilb_type),
                                            ilb_response=ilb_response,
                                            vpc_peer_connection=vpc_peer_connection,
                                            vpc_endpoint_service_name=vpc_endpoint_service_name,
                                            initial=False)

    ilb_dns = add_message.get('DNS-NAME', None)
    logger.info("ilb dns name: {}".format(ilb_dns))

    if role_arn:
        logger.info("[handle_ilb_add] Role ARN specified. Calling handle_")
        assume_role_and_send_to_queue(role_arn, add_message, queue_url)
    else:
        logger.info("[hanlde_ilb_add] Send to queue in same account.")
        send_to_queue(add_message, queue_url, None)
    logger.info("****************** handle ilb add  END **************")


def add_ilb_route_table_entries(ilb_route_table, target_cidrs, vpc_peer_connection):
    """
    This method adds route table entries to the ilb route table
    in order to direct traffic accross the vpc peering connection

    :param: ilb_route_table
    :param: target_cidrs
    :param: vpc_peer_connection
    :return:
    """
    logger.info('****************** add ilb route table entries  START **************')
    for target_cidr in target_cidrs:
        create_vpcpeer_routetable_entry(DestinationCidrBlock=target_cidr,
                                        RouteTableId=ilb_route_table,
                                        VpcPeeringConnectionId=vpc_peer_connection)
    logger.info("****************** add ilb route table entries  END **************")


def delete_ilb_route_table_entries(ilb_route_table, target_cidrs):
    """
    This method deletes route table entries from the ilb route table

    :param: ilb_route_table
    :param: target_cidrs
    :return:
    """
    logger.info('****************** delete ilb route table entries  START **************')
    for target_cidr in target_cidrs:
        delete_vpcpeer_routetable_entry(DestinationCidrBlock=target_cidr,
                                        RouteTableId=ilb_route_table)
    logger.info("****************** delete ilb route table entries  END **************")


def add_ilb_endpoint_service_principal(vpc_endpoint_service_id, principal_arn):
    logger.info('****************** add ilb endpoint service permissions  START **************')
    response = ec2_client.modify_vpc_endpoint_service_permissions(
        ServiceId=vpc_endpoint_service_id,
        AddAllowedPrincipals=[principal_arn]
    )
    logger.info('[add_ilb_endpoint_service_principal] RESPONSE: {}'.format(response))
    logger.info('****************** add ilb endpoint service permissions  END **************')


def delete_ilb_endpoint_service_principal(vpc_endpoint_service_id, principal_arn):
    logger.info('****************** add ilb endpoint service permissions  START **************')
    response = ec2_client.modify_vpc_endpoint_service_permissions(
        ServiceId=vpc_endpoint_service_id,
        RemoveAllowedPrincipals=[principal_arn]
    )
    logger.info('[delete_ilb_endpoint_service_principal] RESPONSE: {}'.format(response))
    logger.info('****************** add ilb endpoint service permissions  END **************')


def reject_ilb_endpoint_service_connections(vpc_endpoint_service_id):
    """
    Obtains a list of all enpoints connected to the given endpoint service and rejects all of them.
    """
    logger.info('****************** reject ilb endpoint service connections  START **************')
    response = ec2_client.describe_vpc_endpoint_connections(Filters=[{
        'Name': 'service-id',
        'Values': [vpc_endpoint_service_id]
    }])
    # Line below converts the array of connection objects to a list of endpoint ids
    endpointIds = map(lambda connection: connection['VpcEndpointId'], response['VpcEndpointConnections'])
    response = ec2_client.reject_vpc_endpoint_connections(ServiceId=vpc_endpoint_service_id,
                                                          VpcEndpointIds=endpointIds)
    logger.info('****************** reject ilb endpoint service connections  END **************')


def send_response(event, context, responseStatus):
    """

    :param event:
    :param context:
    :param responseStatus:
    :return:
    """

    r = responseStatus.split(":")
    logger.info(r)
    rs = str(r[0])
    reason = ""
    if len(r) > 1:
        reason = str(r[1])
    else:
        reason = 'See the details in CloudWatch Log Stream.'
    logger.info('send_response() to stack -- responseStatus: ' + str(rs) + ' Reason: ' + str(reason))
    response = {
        'Status': str(rs),
        'Reason': str(reason),
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'PhysicalResourceId': event['LogicalResourceId']
    }
    logger.info('RESPONSE: ' + json.dumps(response))
    parsed_url = urlparse(event['ResponseURL'])
    if (parsed_url.hostname == ''):
        logger.info('[ERROR]: Parsed URL is invalid...')
        return 'false'

    logger.info('[INFO]: Sending Response...')
    try:
        with closing(httplib.HTTPSConnection(parsed_url.hostname)) as connection:
            connection.request("PUT", parsed_url.path + "?" + parsed_url.query, json.dumps(response))
            response = connection.getresponse()
            if response.status != 200:
                logger.info('[ERROR]: Received non 200 response when sending response to cloudformation')
                logger.info('[RESPONSE]: ' + response.msg)
                return 'false'
            else:
                logger.info('[INFO]: Got good response')

    except Exception:
        logger.info('[ERROR]: Got ERROR in sending response...')
        return 'false'
    finally:

        connection.close()
        return 'true'


def handle_stack_create(event, context):

    # stackname = event['ResourceProperties']['StackName']
    # lambda_execution_role = event['ResourceProperties']['LambdaExecutionRole']
    # S3BucketName = event['ResourceProperties']['S3BucketName']
    # S3Object = event['ResourceProperties']['S3ObjectName']
    ILB_ARN = event['ResourceProperties']['ILB-ARN']
    is_alb = event['ResourceProperties']['ILB-TYPE'] == 'application'
    ILB_TYPE = 'ALB' if is_alb else 'NLB'
    # NLB_NAME = event['ResourceProperties']['NLB-NAME']
    QueueURL = event['ResourceProperties']['QueueURL']
    # Ignore ExternalId for now
    try:
        RoleARN = event['ResourceProperties']['CrossAccountRoleARN']
    except:
        RoleARN = ''
    # ExternalId = event['ResourceProperties']['ExternalId']
    ExternalId = ''

    if is_alb:
        # ALB uses VPC peering for cross vpc connection
        is_cross_vpc = 'VPCPeerConnection' in event['ResourceProperties']
    else:
        # NLB uses a VPC endpoint service for cross vpc connection
        is_cross_vpc = 'VPCEndpointService' in event['ResourceProperties']

    vpc_peer_connection = 'None'
    vpc_endpoint_service_id = 'None'
    vpc_endpoint_service_name = 'None'
    ilb_route_table = ''
    target_cidrs = ''

    if is_cross_vpc and is_alb:
        # Get VPC peering info for ADD-ALB cross vpc message
        vpc_peer_connection = event['ResourceProperties']['VPCPeerConnection']
        target_cidrs = event['ResourceProperties']['PeerConnectionTargetCIDRs']
        num_firewall_azs = event['ResourceProperties']['NumberOfFWAZs']
        if len(target_cidrs) != int(num_firewall_azs):
            logger.error('[handle_stack_create] ERROR: The number of firewall AZs specified ({}) must match the length of the list of trust subnet CIDRs ({}) specified'.format(num_firewall_azs, len(target_cidrs)))
            send_response(event, context, "FAILED")
            return

    if is_cross_vpc and not is_alb:
        # Get VPC endpoint service info for ADD-NLB cross vpc message
        vpc_endpoint_service_id = event['ResourceProperties']['VPCEndpointService']
        vpc_endpoint_service_name = get_vpc_endpoint_service_name(vpc_endpoint_service_id)
        fw_account_arn = event['ResourceProperties']['FWAccountID']

    if is_cross_vpc:
        ilb_route_table = event['ResourceProperties']['ILBRouteTable']
        vpc_cidrs = event['ResourceProperties']['VPCSubnetCIDRs']
        num_azs = event['ResourceProperties']['NumberOfAZs']
        azs = event['ResourceProperties']['VpcAzs']
        # Check that the lists entered by the user match the lengths entered by the user
        if len(vpc_cidrs) != int(num_azs) or len(azs) != int(num_azs):
            logger.error('[handle_stack_create] ERROR: Number of VPC AZs specified ({}) must match the length of VPC subnet CIDR list ({}) and the length of the AZ list ({})'.format(num_azs, len(vpc_cidrs), len(azs)))
            send_response(event, context, "FAILED")
            return

    try:
        ilb_response = lb_client.describe_load_balancers(
            LoadBalancerArns=[ILB_ARN]
        )
        if ilb_route_table != 'None':
            if is_cross_vpc:
        	    add_ilb_route_table_entries(ilb_route_table=ilb_route_table,
                                        target_cidrs=target_cidrs,
                                        vpc_peer_connection=vpc_peer_connection)
        else:
            logger.info("route table insertions are done manually for exisitng application")
        if is_cross_vpc and not is_alb:
            add_ilb_endpoint_service_principal(vpc_endpoint_service_id=vpc_endpoint_service_id,
                                               principal_arn=fw_account_arn)

        handle_ilb_add(ilb_response=ilb_response,
                       ilb_type=ILB_TYPE,
                       is_cross_vpc=is_cross_vpc,
                       vpc_peer_connection=vpc_peer_connection,
                       vpc_endpoint_service_name=vpc_endpoint_service_name,
                       ilb_route_table=ilb_route_table,
                       queue_url=QueueURL,
                       role_arn=RoleARN)
        send_response(event, context, "SUCCESS")
        logger.info("Successfully completed the lambda function deployment and execution.")
    except Exception, e:
        logger.info(e)
        logger.info("Failure encountered during lambda function deployment and execution.")
        send_response(event, context, "FAILED")
    finally:
        logger.info("Returning from lambda function deployment and execution.")


def handle_stack_delete(event, context):
    """

    :param event:
    :param context:
    :return:
    """

    # stackname = event['ResourceProperties']['StackName']
    # ILB_ARN = event['ResourceProperties']['ILB-ARN']
    # ILB_NAME = event['ResourceProperties']['ILB-NAME']
    ILB_DNS = event['ResourceProperties']['ILB-DNS']
    is_alb = event['ResourceProperties']['ILB-TYPE'] == 'application'
    ILB_TYPE = 'ALB' if is_alb else 'NLB'
    QueueURL = event['ResourceProperties']['QueueURL']
    # Ignore ExternalId for now
    try:
        RoleARN = event['ResourceProperties']['CrossAccountRoleARN']
    except:
        RoleARN = ''
    # ExternalId = event['ResourceProperties']['ExternalId']
    ExternalId = ''

    if is_alb:
        # ALB uses VPC peering for cross vpc connection
        is_cross_vpc = 'VPCPeerConnection' in event['ResourceProperties']
    else:
        # NLB uses a VPC endpoint service for cross vpc connection
        is_cross_vpc = 'VPCEndpointService' in event['ResourceProperties']

    ilb_route_table = ''
    target_cidrs = ''
    vpc_endpoint_service_name = 'None'

    if is_cross_vpc and is_alb:
        target_cidrs = event['ResourceProperties']['PeerConnectionTargetCIDRs']

    if is_cross_vpc and not is_alb:
        # Get VPC endpoint service info for ADD-NLB cross vpc message
        vpc_endpoint_service_id = event['ResourceProperties']['VPCEndpointService']
        vpc_endpoint_service_name = get_vpc_endpoint_service_name(vpc_endpoint_service_id)
        fw_account_arn = event['ResourceProperties']['FWAccountID']

    if is_cross_vpc:
        ilb_route_table = event['ResourceProperties']['ILBRouteTable']

    logger.info("[handle_stack_delete] Received ILB_DNS: {}".format(ILB_DNS))

    try:
        handle_ilb_delete(ilb_dns=ILB_DNS,
                          ilb_type=ILB_TYPE,
                          queue_url=QueueURL,
                          role_arn=RoleARN,
                          vpc_endpoint_service_name=vpc_endpoint_service_name)
        if is_cross_vpc and not is_alb:
            reject_ilb_endpoint_service_connections(vpc_endpoint_service_id=vpc_endpoint_service_id)
            delete_ilb_endpoint_service_principal(vpc_endpoint_service_id=vpc_endpoint_service_id,
                                                  principal_arn=fw_account_arn)
        if ilb_route_table != 'None':
            if is_cross_vpc:
                delete_ilb_route_table_entries(ilb_route_table=ilb_route_table,
                                           target_cidrs=target_cidrs)
        else:
            logger.info("route table deleteions are done manually for exisitng application")        	                                  
    except Exception, e:
        logger.info("[handle_stack_delete] Exception occurred: {}".format(e))
    finally:
        send_response(event, context, "SUCCESS")


def ilb_deploy_handler(event, context):
    """
    This method serves and the first point of contact
    for the AWS Cloud Formation Custom Resource. It gets invoked
    when the custom resource is executed by the Cloud Formation Service.

    The method serves the following
    :param event:
    :param context:
    :return:
    """

    logger.info("Called with event: {}".format(event))
    if event['RequestType'] == 'Delete':
        handle_stack_delete(event, context)
    elif event['RequestType'] == 'Create':
        handle_stack_create(event, context)
