"""
/*****************************************************************************
 * Copyright (c) 2016, Palo Alto Networks. All rights reserved.              *
 *                                                                           *
 * This Software is the property of Palo Alto Networks. The Software and all *
 * accompanying documentation are copyrighted.                               *
 *****************************************************************************/

Copyright 2016 Palo Alto Networks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

from __future__ import print_function

import boto3
import botocore
import json
import logging
import time
import socket
import struct
import decimal
import uuid
import logging
import urllib
from urllib.request import urlopen
import ssl
import xml.etree.ElementTree as et
from http.client import HTTPSConnection
import re
import os
import traceback
from . import xmltodict
from boto3.dynamodb.conditions import Key, Attr
from urllib.parse import urlparse, unquote_plus

logger = logging.getLogger()

# Enable creation of S3 bucket per-ASG
enable_s3=False
num_nlb_port=1280
start_nlb_port=81

######## BOTO3 Clients and Resources #############
s3 = boto3.client('s3')
asg = boto3.client('autoscaling')
ec2 = boto3.resource('ec2')
ec2_client = ec2.meta.client
lambda_client = boto3.client('lambda')
iam = boto3.client('iam')
events_client = boto3.client('events')
cloudwatch = boto3.client('cloudwatch')
elb = boto3.client('elb')
elbv2 = boto3.client('elbv2')
sqs = boto3.client('sqs')
sns = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')


def purge_stack_queue(queue_url):
    """
    Delete all the messages in the queue

    :param queue_url: URL of the queue
    :return: None
    """
    sqs.purge_queue(QueueUrl=queue_url)

def set_queue_attributes(queue_url, retention_period):
    """
    Set the queue attributes

    :param queue_url: URL of the queue
    :param retention_period: Duration of time that the message
                             will be retained for.
    :return: None
    """
    try:         
        sqs.set_queue_attributes(QueueUrl=queue_url,
                                 Attributes={
                                    'MessageRetentionPeriod': str(retention_period)
                                }
        )
        
    except Exception as e:
        logger.exception('Unable to set queue attributes')
        

def get_from_sqs_queue(queue_url, visiblity_timeout=10, waittimes_seconds=5):
    """
     Retrieve data from a queue

     :param queue_url: URL of the queue
     :param visiblity_timeout: The duration during which the message will not
                               be available to other consumers
     :param waittimes_seconds: Wait timeout
     :return: None
    """
    stack_msg = None
    stack_attrs = None

    for retry in range(0, 10):
        time.sleep(5) 
        try:
            logger.info('Retrieve data from queue: {}'.format(queue_url))
            response = sqs.receive_message(QueueUrl=queue_url, 
                                       MaxNumberOfMessages=10, 
                                       AttributeNames=['All'],
                                       MessageAttributeNames=['All'], 
                                       VisibilityTimeout=visiblity_timeout,
                                       WaitTimeSeconds=waittimes_seconds)

            logger.info('Retrieved response: {}'.format(response))

            for message in response.get('Messages', []):
                if message:
                    msg_attr = message.get('MessageAttributes', None)
                    handle = message.get('ReceiptHandle', None)
                    if msg_attr and 'panw-fw-stack-params' in msg_attr.keys():
                        stack_msg = message.get('Body', None)
                        logger.info('Stack message: {}'.format(stack_msg))
                    attrs = message.get('Attributes')
                    senttimestamp = attrs.get('SentTimestamp', None)
                    logger.info('msg details:: msg: {} ts: {} rh: {}'.format(stack_msg, senttimestamp, handle))
                    return (stack_msg, senttimestamp, handle) 
        except Exception as e:
            logger.exception('Exception occurred retrieving message from queue: {}'.format(e))

    
    return None, None, None

def send_message_to_queue(queue_url, str_message):
    """
    Send a message on the specified queue.

    :param queue_url: The URL of the queue
    :param str_message: Message to send to the queue
    :return:  None
    """
    logger.info("Sending message to queue: {}".format(str_message))
    ret_dict = sqs.send_message(
        QueueUrl=queue_url,
        MessageBody=str_message,
        MessageAttributes={
            'panw-fw-stack-params': {
                'StringValue': '1000',
                'DataType' : 'String'
            }
        }
    )
    logger.info("Response data from sending message to queue: {}".format(ret_dict))

def delete_message_from_queue(queue_url, receipt_handle):
    """
    Delete a message from the SQS queue.

    :param queue_url: The URL of the queue
    :param receipt_handle: The receipt handle of the message
    :return: None
    """
    logger.info('Attempting to delete the message from the queue')

    try:
        sqs.delete_message(QueueUrl=queue_url, ReceiptHandle=receipt_handle)
    except Exception as e:
        logger.exception('Exception occurred while attemption to delete message from the queue.')

def get_from_ilb_queue(queue_url, visiblity_timeout=10, waittimes_seconds=0):
    """
    Retrieve a message from nlb queue

    :param queue_url:
    :param visiblity_timeout:
    :param waittimes_seconds:
    :return: msg or None
    """
    nlb_msg = None
    nlb_attrs = None
        
    try:
        logger.info('Retrieve data from queue: {}'.format(queue_url))
        response = sqs.receive_message(QueueUrl=queue_url,
                                       MaxNumberOfMessages=1,
                                       AttributeNames=['All'],
                                       MessageAttributeNames=['All'],
                                       VisibilityTimeout=visiblity_timeout,
                                       WaitTimeSeconds=waittimes_seconds)
    
        logger.info('Retrieved response: {}'.format(response))
        
        for message in response.get('Messages', []):
            if message:
                msg_attr = message.get('MessageAttributes', None)
                handle = message.get('ReceiptHandle', None)
                if msg_attr and 'panw-fw-nlb-msg' in msg_attr.keys():
                    nlb_msg = message.get('Body', None)
                    logger.info('NLB message: {}'.format(nlb_msg))
                attrs = message.get('Attributes')
                senttimestamp = attrs.get('SentTimestamp', None)
                logger.info('ILB queue msg details:: msg: {} ts: {} rh: {}'.format(nlb_msg, senttimestamp, handle))
                return (nlb_msg, senttimestamp, handle)
    except Exception as e:
        logger.exception('Exception occurred retrieving message from ILB queue: {}'.format(e))

    return None, None, None

def send_message_to_nlb_queue(queue_url, str_message):
    """
    Send a message on the Network Load Balancer queue.

    :param queue_url: The URL of the queue
    :param str_message: Message to send to the queue
    :return:  None
    """


    logger.info("Sending message to ILB queue: {}".format(str_message))
    ret_dict = sqs.send_message(
        QueueUrl=queue_url,
        MessageBody=str_message,
        MessageAttributes={
            'panw-fw-nlb-msg': {
                'StringValue': '1000',
                'DataType' : 'String'
            }
        }
    )
    logger.info("Response data from sending message to ILB queue: {}".format(ret_dict))

def substring_after(s, delim):
    """

    :param s:
    :param delim:
    :return:
    """
    return s.partition(delim)[2]

def fix_unicode(data,unicode):
    """
        Method to convert opaque data from unicode to utf-8
        :param data: Opaque data
        :return: utf-8 encoded data
    """
    if isinstance(data):
        return data.encode('utf-8')
    elif isinstance(data, dict):
        data = dict((fix_unicode(k), fix_unicode(data[k])) for k in data)
    elif isinstance(data, list):
        for i in range(0, len(data)):
            data[i] = fix_unicode(data[i])

    return data

def fix_subnets(data1):
    """

    :param data1:
    :return:
    """
    data=str(data1)
    data=data.replace("'", "")
    data=data.replace("[", "")
    data=data.replace("]", "")
    return data
  
def ip2int(addr):
    """

    :param addr:
    :return:
    """
    return struct.unpack("!I", socket.inet_aton(addr))[0]

def int2ip(addr):
    """

    :param addr:
    :return:
    """
    return socket.inet_ntoa(struct.pack("!I", addr))
 
def get_subnet_and_gw(ip_cidr):
    """
    Extract subnet and gateway from subnet cidr in AWS

    :param ip_cidr:
    :return:
    """
    addr_mask = ip_cidr.split('/')
    addr = addr_mask[0]
    try:
        mask = addr_mask[1]
    except IndexError:
        mask = '32'

    # convert to int
    addr = ip2int(addr)
    mask = int(mask)

    subnet = addr & ((0xFFFFFFFF << (32 - mask)) & 0xFFFFFFFF)
    if mask == 32:
        gw = addr
    else:
        gw = subnet | 1

    return (int2ip(subnet), int2ip(gw))

def retrieve_fw_ip(instance_id):
    """
    Retrieve the IP of the Instance

    :param instance_id: The id of the instance
    :type instance_id: str
    """

    eni_response=ec2_client.describe_network_interfaces(Filters=[{'Name': "attachment.instance-id", 'Values': [instance_id]},
                    {'Name': "attachment.device-index", 'Values': ["1"]}])

    logger.info("Describe network interfaces response: {}".format(eni_response))

    eniId=""
    for eni in eni_response['NetworkInterfaces']:
        eniId=eni['NetworkInterfaceId']

    if eniId == "":
        logger.error('Mgmt ENI ID not found for instance: ' + instance_id)
        return False
    

    logger.info('Eni ID (eth1) for instance : ' + instance_id + ' is: ' + eniId)
    try:
        response=ec2_client.describe_network_interfaces(NetworkInterfaceIds=[eniId])
    except Exception as e:
        logger.error("[Describe network interfaces failed while retrieving fw ip]: {}".format(e))
        return False

    ip="NO_IP"
    try:
        for i in response['NetworkInterfaces']:
            logger.info(i['PrivateIpAddresses'])
            ip=i['PrivateIpAddress']
    except Exception as e:
        logger.error("[FW IP Address in retrieve fw ip]: {}".format(e))
        ip="NO_PrivateIP_ADDR"

    if ip.find("NO_") >= 0:
        logger.error('We failed to get either EIP or Private IP for instance: ' + str(instance_id) + ' IP: ' + ip)
        logger.error('We will not proceed further with this Instance: ' + str(instance_id))
        return False
    else:
        logger.info('The IP address of the fw device is: {}'.format(ip))
        return ip

def retrieve_fw_ip_from_db(stackname, region, instanceId):
    """
    Retrieve the IP of the instance from Database Table
    :param stackname:
    :param region:
    :param instanceId:
    :Return:
    """

    try:
        response = firewall_table_get_instance(stackname, region, instanceId)
        logger.info(str(response))
        return response['Items'][0]['MgmtPrivIP']
    except Exception as e:
        logger.exception("[Unable to get firewall IP]: {}".format(e))
        return None
    
def get_asg_name(stackname, elbtg):
    """
    Construct asg name

    :param stackname:
    :param :elbtg
    :return: asg name
    """
    name = stackname[:10] + '-' + elbtg + '_ASG'
    return name[-63:len(name)]    

def get_sched_func_name(stackname, elbtg):
    """

    :param stackname:
    :param elbtg:
    :return:
    """
    name= stackname[:10] + '-'+ elbtg + '-lambda-sched-event'
    return name[-63:len(name)]

def get_lambda_statement_id(stackname, elbtg):
    """

    :param stackname:
    :param elbtg:
    :return:
    """
    statementId = stackname[:10] + '-' + elbtg + '-lambda_add_perm'
    return statementId[-63:len(statementId)]

def get_lc_name(stackname, elbtg):
    """

    :param stackname:
    :param elbtg:
    :return:
    """
    name = stackname[:10] + '-' + elbtg + '_ASG_LC'
    return name[-63:len(name)]

def get_cw_name_space(stackname, asg_name):
    """

    :param stackname:
    :param asg_name:
    :return:
    """
    name = asg_name
    return name[-63:len(name)]

def get_s3_bucket_name(stackname, ilbtag):
    """
    
    :param stackname:
    :param ilbtag:
    :return:
    """
    logger.info('Stackname: ' + stackname)
    name = stackname + '-bstrap-'
    name=name.lower()
    return name[-63:len(name)]

def get_nlb_table_name(stackname, region):
    """
    
    :param stackname:
    :param region:
    :return:
    """
    name=stackname+"-ilb-"+region
    return name

def get_firewall_table_name(stackname, region):
    """
 
    :param stackname:
    :param region:
    :return:
    """
    name=stackname+"-firewall-"+region
    return name

#DUMMY FUNC -- NOT USED
def get_s3_bucket_name1(stackname, ilbtag, ip_address):
    if enable_s3 == False:
        return "enable_s3_is_false"

    first=stackname.split('-')
    try:
        response=elbv2.describe_load_balancers(Names=[ilbtag])
    except Exception as e:
         logger.info("[S3 Delete Bucket]: {}".format(e))
         return "s3-bucket-not-found"

    ilb=first[0] + str(ip_address.replace(".", "-"))
    logger.info('ILB: ' + ilb)
    cnt=0
    for i in response['LoadBalancers']:
        logger.info('DNSName: ' + i['DNSName'])
        dnsname=i['DNSName']
        list=dnsname.split('.')
        ilb=ilb + list[0]
        cnt = cnt + 1
 
    logger.info('ILB: ' + ilb)
    name=""
    if cnt == 0:
       logger.critical('Problem with S3 bucketnaming: Didnt find ILB' + ilb)
       name = stackname + '-bstrap-' + str(ip_address.replace(".", "-"))
    elif cnt > 1:
       logger.crictical('Problem with S3 bucketnaming: ' + ilb)
       name = stackname + '-bstrap-' + str(ip_address.replace(".", "-"))
    else:
       name=ilb

    name=name.lower()
    return name[-63:len(name)]

def get_lambda_cloud_watch_func_name(stackname, asg_name, instanceId):
    """
    Generate the name of the cloud watch metrics as a function
    of the ASG name and the instance id.
    :param stackname:
    :param asg_name:
    :param instanceId:
    :return: str
    """
    name = asg_name + '-cwm-' + str(instanceId)
    return name[-63:len(name)]

def get_event_rule_name(stackname, instanceId):
    """
    Generate the name of the event rule.

    :param stackname:
    :param instanceId:
    :return: str
    """
    name = stackname + '-cw-event-rule-' + str(instanceId)
    return name[-63:len(name)]

def get_statement_id(stackname, instanceId):
    """

    :param stackname:
    :param instanceId:
    :return:
    """
    name = stackname + '-cw-statementid-' + str(instanceId)
    return name[-63:len(name)]

def get_target_id_name(stackname, instanceId):
    """

    :param stackname:
    :param instanceId:
    :return:
    """
    name = stackname + '-lmda-target-id' + str(instanceId)
    return name[-63:len(name)]

def choose_subnet(subnet, AvailabilityZone):
    """
    Method to identify the subnet id based upon the
    availability zone.

    :param subnet:
    :param AvailabilityZone:
    :return:
    """
    logger.info('Choose Subnets: ')
    logger.info(subnet)
    list_subnets=subnet.split(",")
    response=ec2_client.describe_subnets(SubnetIds=list_subnets)
    ret_subnets=""
    for i in response['Subnets']:
        if i['AvailabilityZone'] == AvailabilityZone:
            if ret_subnets == "":
                ret_subnets=i['SubnetId']
            else:
                ret_subnets= ret_subnets + "," + i['SubnetId']

    logger.info('Return Subnets for AZ: ' + AvailabilityZone + ' Subnets: ' + ret_subnets)
    return ret_subnets

def getASGTag(rid, key):
    """
    Set tags on a specified auto scale group.
   
    .. note:: This method is important from the perspective
              that it allows the lambda function code to
              distinguish ```PAN-FW``` deployed ASG's from
              other ASG's that might already exist in the
              customer VPC.
   
    :param rid: The name of the ASG
    :param key: The tag to retrieve
    :return: None or str
    """
    logger.info('Getting all the tags for rid: ' + rid)
    try:
        response=asg.describe_tags(Filters=[{'Name': 'auto-scaling-group', 'Values': [rid]}])
    except Exception as e:
         logger.info("[Failed to describe tag]: {}".format(e))
         return None

    logger.info(response)
    for i in response['Tags']:
        if i['Key'] == key:
            return i['Value']

    return None

def setASGTag(rid, key, value):
    """
    Set ```PAN-FW``` specific tags on an ASG.

    .. note:: This method is important from the perspective
              that it allows the lambda function code to
              distinguish ```PAN-FW``` deployed ASG's from
              other ASG's that might already exist in the
              customer VPC.

    :param rid: Name of the ASG
    :param key: Tag
    :param value: Tag Value
    :return: None
    """
    try:
        asg.create_or_update_tags(Tags=[{'ResourceId': rid, 'ResourceType': "auto-scaling-group", 'Key': key, 'Value': value, 'PropagateAtLaunch': False}])
    except Exception as e:
         logger.info("[Failed to Set Tag]: {}".format(e))
    return

def runCommand(gcontext, cmd, gwMgmtIp, api_key):
    """

    Method to run generic API commands against a PAN Firewall.

    .. note:: This is a generic method to interact with PAN
              firewalls to execute api calls.

    :param gcontext: SSL Context
    :param cmd: Command to execute
    :param gwMgmtIp: Management IP of the PAN FW
    :param api_key: API key of the Firewall
    :return: None or str
    """
    try:
        response = urlopen(cmd, context=gcontext, timeout=5).read().decode('utf-8')
        logger.info("[RESPONSE] in send command: {}".format(response))
    except Exception as e:
        logger.error("[RunCommand Response Fail]: {}".format(e))
        return None

    resp_header = et.fromstring(response)

    if resp_header.tag != 'response':
        logger.error("[ERROR]: didn't get a valid response from Firewall command: " + cmd)
        return None

    if resp_header.attrib['status'] == 'error':
        logger.error("[ERROR]: Got an error for the command: " + cmd)
        return None

    if resp_header.attrib['status'] == 'success':
        return response

    return None

def runShutdownCommand(gcontext, cmd, gwMgmtIp, api_key):
    """
    Method to shutdown a device.

    :param gcontext:
    :param cmd:
    :param gwMgmtIp:
    :param api_key:
    :return: bool 
    """
    try:
        response = urlopen(cmd, context=gcontext, timeout=5).read().decode('utf-8')
        logger.info("[RESPONSE] in send command: {}".format(response))
    except Exception as e:
        logger.warning("[RunCommand Response Fail]: firewall could be shutting down {}".format(e))
        return True

    resp_header = et.fromstring(response)

    if resp_header.tag != 'response':
        logger.error("[ERROR]: didn't get a valid response from Firewall command: " + cmd)
        return False

    if resp_header.attrib['status'] == 'error':
        logger.error("[ERROR]: Got an error for the command: " + cmd)
        return False

    if resp_header.attrib['status'] == 'success':
        return True

    return False
def send_command(conn, req_url):
    """
    An alternative interface to interact with the PAN FW's

    :param conn:
    :param req_url:
    :return: dict
    """
    conn.request("POST", req_url)
    resp = conn.getresponse()
    msg = resp.read().decode('utf-8')
    
    if resp.status == 200 :
        logger.info('[200 OK] CMD: ' +  req_url + '    MSG in send_command(): ' + msg)
        root = et.fromstring(msg)
        if root.attrib['status'] == 'success':
            logger.info('Success response status. Data: {} Type: {}'.format(str(root), type(root)))
            return {'result': True, 'data': root}
        elif root.attrib['status'] == 'error':
            logger.info('Command succeeded but the status is error.')
            conn.close()
            logger.info('Error response status. Data: {} Type: {}'.format(str(root), type(root)))
            return {'result': False, 'data': root}
        else:
            conn.close()
            logger.error('Failure received in send_command for URL: ' + str(req_url))
            return {'result': False, 'data': msg}
    else:
        logger.error('Status is not 200 in send_command for URL: ' + str(req_url))
        logger.info('CMD: ' +  req_url + '    MSG in send_command(): ' + msg)
        conn.close()
        return {'result': False, 'data': None}

def remove_device(stackname, remove, PanoramaIP, api_key, dev_group, tp_group, serial_no, gwMgmtIp):
    """
    Method to remove a device from Panorama.

    :param stackname:
    :param remove:
    :param PanoramaIP:
    :param api_key:
    :param dev_group:
    :param tp_group:
    :param serial_no:
    :param gwMgmtIp:
    :return: None or str
    """
    conn = HTTPSConnection(PanoramaIP, 443, timeout=10, context=ssl._create_unverified_context())

    if dev_group != "":
        cmd_show_device_group = "/api/?type=op&cmd=<show><devicegroups><name>%s</name></devicegroups></show>&key=%s"%(dev_group, api_key)
        response = send_command(conn, cmd_show_device_group)
        if response['result'] == False:
            conn.close()
            logger.error('Panorama: Fail to execute Panorama API show dg for device: ' + gwMgmtIp)
            return None

        logger.info('show dg: ' + str(response))
        #data = response['data'].findall('./result/devices/*')
        data = response['data'].findall('./result/devicegroups/entry/devices/*')

        for entry in data:
            ip_tag = entry.find('ip-address')
            if ip_tag is None:
                print('ip_tag: ' + str(ip_tag))
                pass
            else:
                ip_addr = ip_tag.text
                if ip_addr == gwMgmtIp:
                    serial_no = entry.attrib.get('name')
                    logger.info('entry: ' + str(entry.tag) + ' ' + str(entry.text) + ' ' + str(entry.attrib))
                    logger.info('serial_no in show dg: ' + str(serial_no))

        if serial_no == "":
            logger.error('Panorama: Fail to find serial number for device: ' + gwMgmtIp)
        elif remove == True:
            logger.info('show dg: serial number is: (' + str(serial_no) + ')')
            cmd_delete_from_devgroup = "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='%s']/devices/entry[@name='%s']&key=%s"%(dev_group, serial_no, api_key)
            response = send_command(conn, cmd_delete_from_devgroup)
            if response['result'] == False:
                conn.close()
                logger.error('Panorama: Fail to execute Panorama API delete dg for device: ' + gwMgmtIp)
                return None

    if tp_group != "":
        if serial_no == "":
            cmd_show_template = "/api/?type=op&cmd=<show><templates><name>%s</name></templates></show>&key=%s"%(tp_group, api_key)
            response = send_command(conn, cmd_show_template)
            if response['result'] == False:
                conn.close()
                logger.error('Panorama: Fail to execute Panorama API show template for device: ' + gwMgmtIp)
                return None

            logger.info('show tpl: response: ' + str(response))
            #data = response['data'].findall('./result/devices/*')
            data = response['data'].findall('./result/templates/entry/devices/*')

            for entry in data:
                ip_tag = entry.find('ip-address')
                if ip_tag is None:
                    print('ip_tag: ' + str(ip_tag))
                    pass
                else:
                    ip_addr = ip_tag.text
                    if ip_addr == gwMgmtIp:
                        serial_no = entry.attrib.get('name')
                        logger.info('entry: ' + str(entry.tag) + ' ' + str(entry.text) + ' ' + str(entry.attrib))
                        logger.info('serial_no in show tpl: ' + str(serial_no))

            if serial_no == "":
                logger.error('Panorama: Fail to serial number in show template for device: ' + gwMgmtIp)


        if serial_no != "" and remove == True:
            cmd_delete_from_tpgroup = "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/template/entry[@name='%s']/devices/entry[@name='%s']&key=%s"%(tp_group, serial_no, api_key)
            #send and make sure it is successful
            response = send_command(conn, cmd_delete_from_tpgroup)

            if response['result'] == False:
                conn.close()
                logger.error('Panorama: Fail to execute Panorama API delete template for device: ' + gwMgmtIp)
                return None

    if serial_no == "":
        cmd_show_all_devices = "/api/?type=op&cmd=<show><devices><all></all></devices></show>&key=%s"%(api_key)
        response = send_command(conn, cmd_show_all_devices)
        if response['result'] == False:
            conn.close()
            logger.error('Panorama: Fail to execute Panorama API show devices for device: ' + gwMgmtIp)
            return None

        logger.info('show all devices: response: ' + str(response))
        data = response['data'].findall('./result/devices/*')

        for entry in data:
            ip_tag = entry.find('ip-address')
            if ip_tag is None:
                pass
            else:
                ip_addr = ip_tag.text
                if ip_addr == gwMgmtIp:
                    serial_no = entry.attrib.get('name')

        if serial_no == "":
            logger.error('Panorama: No registered device found with IP address: ' + gwMgmtIp)
            conn.close()
            return "Done"

    if remove == False:
        conn.close()
        return serial_no

    cmd_delete_device = "/api/?type=config&action=delete&xpath=/config/mgt-config/devices/entry[@name='%s']&key=%s"%(serial_no, api_key)
    response = send_command(conn, cmd_delete_device)
    if response['result'] == False:
        conn.close()
        logger.error('Panorama: Fail to execute Panorama API delete device for device: ' + gwMgmtIp)
        return None

    logger.info('delete unmanaged device: response: ' + str(response))
    cmd_commit = "/api/?type=commit&cmd=<commit></commit>&key="+api_key
    response = send_command(conn, cmd_commit)

    if response['result'] == False:
        conn.close()
        logger.error('Panorama: Fail to execute Panorama API commit for device: ' + gwMgmtIp)
        return None

    job_id=""
    data = response['data'].findall('./result/*')
    for entry in data:
        if entry.tag == 'job':
            job_id = entry.text

    if job_id == "":
        conn.close()
        return None

    logger.info('Commit is being done')
    cmd_commit_success  = "/api/?type=op&cmd=<show><jobs><id>"+job_id+"</id></jobs></show>&key="+api_key
    response = send_command(conn, cmd_commit_success)

    if response['result'] == False:
        conn.close()
        logger.error('Panorama: Fail to execute Panorama API show jobs for device: ' + gwMgmtIp)
        return None

    conn.close()
    return "Done"

def get_ssl_context():  
    """
    Create default ssl context
    """
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.options = ssl.PROTOCOL_TLSv1_2
    return ctx

def execute_api_request(gwMgmtIp, port, cmd):
    """
    Execute API requests against the FW.
    :param gwMgmtIp:
    :param port:
    :param cmd:
    :return:
    """
    conn = None
    conn = HTTPSConnection(gwMgmtIp, port, timeout=10, context=ssl._create_unverified_context())
    response = None
    ex_occurred = False
    try:
        response = send_command(conn, cmd)
    except Exception as e:
        logger.exception('Executing API Request. Cmd: {} {}'.format(cmd, e))
        ex_occurred = True

    if ex_occurred:
        ctx = get_ssl_context()
        logger.warning('Exception occurred in the first attempt. Attempting again with default ssl context')
        response = None
        ctx = get_ssl_context()
        conn = HTTPSConnection(gwMgmtIp, 443, timeout=10, context=ctx)
        response = send_command(conn, cmd)

    conn.close()
    return response

def get_device_serial_no(gcontext, instanceId, gwMgmtIp, fwApiKey):
    """
    Retrieve the serial number from the FW.

    :param gcontext: ssl context
    :param instanceId: instance Id 
    :param gwMgmtIP: The IP address of the FW
    :param fwApiKey: Api key of the FW

    :return: The serial number of the FW
    :rtype: str
    """

    serial_no = None
    if gwMgmtIp is None:
        logger.error('Firewall IP could not be found. Can not interact with the device')
        return None

    logger.info('Retrieve the serial number from FW {} with IP: {}'.format(instanceId, gwMgmtIp))
    fw_cmd="https://"+gwMgmtIp+"/api/?type=op&key="+fwApiKey+"&cmd=<show><system><info/></system></show>"
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, fwApiKey)
        if response is None:
            pan_print('CFG_FW_GET_SERIAL_NO: Failed to run command: ' + fw_cmd)
            return None
    except Exception as e:
        pan_print("[CFG_FW_GET_SERIAL_NO]: {}".format(e))
        return None

    resp = et.fromstring(response) 
    serial_info = resp.findall(".//serial")
    for info in serial_info:
        serial_no = info.text

    if not serial_no:
        logger.error("Unable to retrieve the serial number from device: {} with IP: {}".format(instanceId, gwMgmtIp))

    return serial_no

def get_device_serial_no_from_db(stackname, region, instanceId):
    """
    Retrieve the serial number from the FW.

    :param stackname:
    :param region:
    :param instanceId:
    :Return: 
    """
    try:
        response = firewall_table_get_instance(stackname, region, instanceId)
        logger.info(str(response))
        return response['Items'][0]['SerialNo']
    except Exception as e:
        logger.exception("[Unable to get device serial no]: {}".format(e))
        return None


def deactivate_fw_license_panorama(panorama_ip,panorama_key,serial_no):
    url = "https://" + panorama_ip + "/api/?type=op&key=" + panorama_key
    url += "&cmd=<request><batch><license><deactivate><VM-Capacity>"
    url += "<mode>auto</mode>"
    url += "<devices>" + serial_no + "</devices>"
    url += "</VM-Capacity></deactivate></license></batch></request>"
    ok, result = execute_command(url)
    if not ok:
        logger.error('Deactivation of VM with serial %s failed' % serial_no)
        return False, result
    return True, result

def deactivate_fw_license(gcontext, instanceId, gwMgmtIp, fwApiKey):
    """
    Call the FW to deactivate the license from the licensing
    server

    :param gcontext: ssl context
    :param instanceId: instance Id
    :param gwMgmtIP: The IP address of the FW
    :param fwApiKey: Api key of the FW

    :return: Api call status
    :rtype: bool 
    """

    if gwMgmtIp is None:
        logger.error('Firewall IP could not be found. Can not interact with the device')
        return False

    logger.info('Deactivate and the license for FW: {} with IP: {}'.format(instanceId, gwMgmtIp))
   
    fw_cmd = "https://{}/api/?type=op&key={}&cmd=<request><license><deactivate><VM-Capacity><mode>auto</mode></VM-Capacity></deactivate></license></request>".format(gwMgmtIp, fwApiKey)
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, fwApiKey)
        if response is None:
            pan_print('CFG_FW_DELICENSE: Failed to run command: ' + fw_cmd)
            return False
    except Exception as e:
        pan_print("[CFG_FW_DELICENSE]: {}".format(e))
        return False

    return True
  
def shutdown_fw_device(gcontext, instanceId, gwMgmtIp, fwApiKey):
    """
    Shutdown the firewall device

    :param gcontext: ssl context
    :param instanceId: instance Id
    :param gwMgmtIP: The IP address of the FW
    :param fwApiKey: Api key of the FW

    :return: Api call status
    :rtype: bool
    """
    if gwMgmtIp is None:
        logger.error('Firewall IP could not be found. Can not interact with the device')
        return False

    logger.info('Shutdown the firewall device : {} with IP: {}'.format(instanceId, gwMgmtIp))
   
    fw_cmd = "https://{}/api/?type=op&key={}&cmd=<request><shutdown><system></system></shutdown></request>".format(gwMgmtIp, fwApiKey)

    try:
        response = runShutdownCommand(gcontext, fw_cmd, gwMgmtIp, fwApiKey)
        if response == False:
            pan_print('CFG_FW_SHUTDOWN: Failed to run command: ' + fw_cmd)
            return False
    except Exception as e:
        pan_print("[CFG_FW_SHUTDOWN]: {}".format(e))
        return False

    return True

def set_deactivate_api_key(gcontext, instanceId, gwMgmtIp, fwApiKey, deactivateApiKey):
    """
    Setup the deactivate api key to allow the FW deactivate sequence
    :param instanceId:
    :param gwMgmtIp:
    :param fwApiKey:
    :param deactivateApiKey:
    :return: bool
    """

    if gwMgmtIp is None:
        logger.error('Firewall IP could not be found. Can not interact with the device')
        return False

    logger.info('Setup the deactivate API Key on the FW for device {} with IP: {}'.format(instanceId, gwMgmtIp))

    fw_cmd = "https://{}/api/?type=op&key={}&cmd=<request><license><api-key><set><key>{}</key></set></api-key></license></request>".format(gwMgmtIp, fwApiKey, deactivateApiKey)
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, fwApiKey)
        if response is None:
            pan_print('CFG_FW_SET_DELIC_KEY: Failed to run command: ' + fw_cmd)
            return False
    except Exception as e:
        pan_print("[CFG_FW_SET_DELIC_KEY]: {}".format(e))
        return False

    return True

def remove_fw_from_panorama(instanceId, KeyPANWPanorama, gwMgmtIp, PanoramaIP, PanoramaDG, PanoramaTPL):
    """

    :param instanceId:
    :param KeyPANWPanorama:
    :param gwMgmtIp:
    :param PanoramaIP:
    :param PanoramaDG:
    :param PanoramaTPL:
    :return:
    """
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)

    logger.info('Panorama: Removing PANW Firewall IP : ' + str(instanceId) + ' from Panorama IP: ' + str(PanoramaIP))

    if gwMgmtIp is None:
        logger.error('Firewall IP could not be found. Can not remove it from Panorama')
        return False

    print('Panorama: Firewall IP address to remove from Panorama is: ' + gwMgmtIp)

    conn = HTTPSConnection(PanoramaIP, 443, timeout=10, context=ssl._create_unverified_context())

    serial_no = ""
    dev_group = PanoramaDG
    tp_group = PanoramaTPL
    api_key = KeyPANWPanorama
    connected="yes"

    if dev_group != "":
        cmd_show_device_group = "/api/?type=op&cmd=<show><devicegroups><name>%s</name></devicegroups></show>&key=%s"%(dev_group, api_key)
        response = send_command(conn, cmd_show_device_group)
        if response['result'] == False:
            conn.close()
            logger.error('Panorama: Fail to execute Panorama API show dg for device: ' + gwMgmtIp)
            return False
        
        logger.info('show dg: ' + str(response))
        #data = response['data'].findall('./result/devices/*')
        data = response['data'].findall('./result/devicegroups/entry/devices/*')

        for entry in data:
            ip_tag = entry.find('ip-address')
            if ip_tag is None:
                logger.info('ip_tag: ' + str(ip_tag))
                pass
            else:
                ip_addr = ip_tag.text
                if ip_addr == gwMgmtIp:
                    serial_no = entry.attrib.get('name')
                    logger.info('entry: ' + str(entry.tag) + ' ' + str(entry.text) + ' ' + str(entry.attrib))
                    logger.info('serial_no in show dg: ' + str(serial_no))
                    state= entry.find('connected')
                    if state is not None:
                        connected=state.text
                        logger.info('show dg device state tag value: ' + str(connected))
                        if str(connected) == "yes":
                            logger.error('Device is still in connected state in show dg: ' + gwMgmtIp)
                            conn.close()
                            return False

        if serial_no == "":
            logger.error('Panorama: Fail to find serial number for device: ' + gwMgmtIp)
        else:
            logger.info('show dg: serial number is: (' + str(serial_no) + ')')
            cmd_delete_from_devgroup = "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='%s']/devices/entry[@name='%s']&key=%s"%(dev_group, serial_no, api_key)
            response = send_command(conn, cmd_delete_from_devgroup)
            if response['result'] == False:
                conn.close()
                logger.error('Panorama: Fail to execute Panorama API delete dg for device: ' + gwMgmtIp)
                return False

    if tp_group != "":
        if serial_no == "":
            cmd_show_template = "/api/?type=op&cmd=<show><templates><name>%s</name></templates></show>&key=%s"%(tp_group, api_key)
            response = send_command(conn, cmd_show_template)
            if response['result'] == False:
                conn.close()
                logger.error('Panorama: Fail to execute Panorama API show template for device: ' + gwMgmtIp)
                return False

            logger.info('show tpl: response: ' + str(response))
            #data = response['data'].findall('./result/devices/*')
            data = response['data'].findall('./result/templates/entry/devices/*')

            for entry in data:
                ip_tag = entry.find('ip-address')
                if ip_tag is None:
                    logger.info('ip_tag: ' + str(ip_tag))
                    pass
                else:
                    ip_addr = ip_tag.text
                    if ip_addr == gwMgmtIp:
                        serial_no = entry.attrib.get('name')
                        logger.info('entry: ' + str(entry.tag) + ' ' + str(entry.text) + ' ' + str(entry.attrib))
                        logger.info('serial_no in show tpl: ' + str(serial_no))
                        state= entry.find('connected')
                        if state is not None:
                            connected=state.text
                            logger.info('show tpl device state tag value: ' + str(connected))
                            if str(connected) == "yes":
                                logger.error('Device is still in connected state in show tpl: ' + gwMgmtIp)
                                conn.close()
                                return False

            if serial_no == "":
                logger.error('Panorama: Fail to get serial number in show template for device: ' + gwMgmtIp)


        if serial_no != "":
            #Get panorama version
            sw_ver = ""
            cmd_show_system_info = "/api/?type=op&cmd=<show><system><info/></system></show>&key=%s"%(api_key)
            response = send_command(conn, cmd_show_system_info)
            if response['result'] == False:
                conn.close()
                logger.error('Panorama: Fail to execute Panorama API show system info')
                return False
            logger.info('show system info: response: ' + str(response))

            sw_info = response['data'].findall(".//sw-version")
            for info in sw_info:
                sw_ver = info.text

            if sw_ver == "":
                logger.error('Panorama: Fail to get software version in show system info')
                cmd_delete_from_tpgroup = "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/template/entry[@name='%s']/devices/entry[@name='%s']&key=%s" % (tp_group, serial_no, api_key)
            else:
                logger.info('Panorama software version: ' + sw_ver)
                try:
                    if float(sw_ver[:3]) >= float(8.1):
                        cmd_delete_from_tpgroup = "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='%s']/devices/entry[@name='%s']&key=%s"%(tp_group, serial_no, api_key)
                    else:
                        cmd_delete_from_tpgroup = "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/template/entry[@name='%s']/devices/entry[@name='%s']&key=%s"%(tp_group, serial_no, api_key)
                except Exception as e:
                    logger.error('Panorama: get invalid software version: ' + sw_ver)
                    cmd_delete_from_tpgroup = "/api/?type=config&action=delete&xpath=/config/devices/entry[@name='localhost.localdomain']/template/entry[@name='%s']/devices/entry[@name='%s']&key=%s" % (tp_group, serial_no, api_key)

            #send and make sure it is successful
            response = send_command(conn, cmd_delete_from_tpgroup)

            if response['result'] == False:
                conn.close()
                logger.error('Panorama: Fail to execute Panorama API delete template for device: ' + gwMgmtIp)
                return False

    if serial_no == "":
        cmd_show_all_devices = "/api/?type=op&cmd=<show><devices><all></all></devices></show>&key=%s"%(api_key)
        response = send_command(conn, cmd_show_all_devices)
        if response['result'] == False:
            conn.close() 
            logger.error('Panorama: Fail to execute Panorama API show devices for device: ' + gwMgmtIp)
            return False

        logger.info('show all devices: response: ' + str(response))
        data = response['data'].findall('./result/devices/*')
                    
        for entry in data:
            ip_tag = entry.find('ip-address')
            if ip_tag is None:
                pass
            else:
                ip_addr = ip_tag.text
                if ip_addr == gwMgmtIp:
                    serial_no = entry.attrib.get('name')
                    state= entry.find('connected')
                    if state is not None:
                        connected=state.text
                        logger.info('show dg device state tag value: ' + str(connected))
                        if str(connected) == "yes":
                            logger.error('Device is still in connected state in show dg: ' + gwMgmtIp)
                            conn.close()
                            return False

        if serial_no == "":
            logger.error('Panorama: No registered device found with IP address: ' + gwMgmtIp)
            conn.close()
            return True
            
    cmd_delete_device = "/api/?type=config&action=delete&xpath=/config/mgt-config/devices/entry[@name='%s']&key=%s"%(serial_no, api_key)
    response = send_command(conn, cmd_delete_device)
    if response['result'] == False:
        conn.close()
        logger.error('Panorama: Fail to execute Panorama API delete device for device: ' + gwMgmtIp)
        return False
            
    logger.info('delete unmanaged device: response: ' + str(response))
    cmd_commit = "/api/?type=commit&cmd=<commit></commit>&key="+api_key
    response = send_command(conn, cmd_commit)
                     
    if response['result'] == False:
        conn.close() 
        logger.error('Panorama: Fail to execute Panorama API commit for device: ' + gwMgmtIp)
        return False
            
    job_id=""
    data = response['data'].findall('./result/*')
    for entry in data:
        if entry.tag == 'job':
            job_id = entry.text
        
    if job_id is None:
        conn.close()
        logger.error('Job id could not be found')
        return False

    logger.info('Commit is being done')
    cmd_commit_success  = "/api/?type=op&cmd=<show><jobs><id>"+job_id+"</id></jobs></show>&key="+api_key
    response = send_command(conn, cmd_commit_success)

    if response['result'] == False:
        conn.close()
        logger.error('Panorama: Fail to execute Panorama API show jobs for device: ' + gwMgmtIp)
        return False

    conn.close()

    return True

def get_panos_version(gcontext, gwMgmtIp, apiKey):
    """
    Retrieve the software version of Panorama or firewall.

    :param gcontext: ssl context
    :param gwMgmtIP: The IP address of the FW
    :param apiKey: Api key of the PANW device

    :return: The software version of the PANW device
    :rtype: str 
    """

    sw_ver = None
    if gwMgmtIp is None:
        logger.error('Device IP could not be found. Can not interact with the PANW device')
        return None

    logger.info('Retrieve the software version from PANW device with IP: {}'.format(gwMgmtIp))
    panos_cmd="https://"+gwMgmtIp+"/api/?type=op&key="+apiKey+"&cmd=<show><system><info/></system></show>"
    try:
        response = runCommand(gcontext, panos_cmd, gwMgmtIp, apiKey)
        if response is None:
            pan_print('CFG_PANOS_GET_SW_VER: Failed to run command: ' + panos_cmd)
            return None 
    except Exception as e:
        pan_print("[CFG_PANOS_GET_SW_VER]: {}".format(e))
        return None 

    resp = et.fromstring(response)
    sw_info = resp.findall(".//sw-version")
    for info in sw_info:
        sw_ver = info.text

    if not sw_ver:
        logger.error("Unable to retrieve the software version from PANW device: {} with IP: {}".format(gwMgmtIp))

    return sw_ver


def release_eip(stackname, instanceId):
    """

    :param stackname:
    :param instanceId:
    :return:
    """
    logger.info('Releasing Elastic IPs...')
    try:
        response=ec2_client.describe_network_interfaces(Filters=[{'Name': "attachment.instance-id", 'Values': [str(instanceId)]}])
        logger.info(response)
        for i in response['NetworkInterfaces']:
            eniId=i['NetworkInterfaceId']
            try:
                ass=i['PrivateIpAddresses']
                strass=str(ass)
                if strass.find("AssociationId") <= 0:
                    continue

                Attachment=i['Attachment']
                aId=i['PrivateIpAddresses'][0]['Association']['AllocationId']
                logger.info('EIP Attachment ID: ' + aId + ' DeviceIndex: ' +  str(Attachment['DeviceIndex']))
                gwMgmtIp=i['PrivateIpAddresses'][0]['Association']['PublicIp']
                ec2_client.disassociate_address(PublicIp=gwMgmtIp)
                ec2_client.release_address(AllocationId=aId)
            except Exception as e:
                logger.info("[Release EIP Loop each ENI]: {}".format(e))

    except Exception as e:
         logger.error("[Release EIP]: {}".format(e))

    return

def random_string(string_length=10):
    """

    :param string_length:
    :return:
    """
    random = str(uuid.uuid4())
    random = random.replace("-","")
    return random[0:string_length]

def common_alarm_func_del(alarmname):
    """

    :param alarmname:
    :return:
    """
    a1=alarmname + '-high'
    cloudwatch.delete_alarms(AlarmNames=[a1])

    a1=alarmname + '-low'
    cloudwatch.delete_alarms(AlarmNames=[a1])
    return

def remove_s3_bucket(s3_bucket_name):
    """

    :param s3_bucket_name:
    :return:
    """
    logger.info('Removing keys from S3 bootstrap bucket: ' + s3_bucket_name)

    try:
        response=s3.list_objects_v2(Bucket=s3_bucket_name)
        for i in response['Contents']:
            logger.info('Deleting object/key: ' + i['Key'])
            s3.delete_object(Bucket=s3_bucket_name, Key=i['Key'])

        logger.info('Delete S3 bootstrap bucket: ' + s3_bucket_name)
        s3.delete_bucket(Bucket=s3_bucket_name)
    except Exception as e:
         logger.info("[S3 Delete Bucket]: {}".format(e))

    return

def remove_asg_life_cycle(asg_name):
    """

    :param asg_name:
    :return:
    """
    logger.info('Removing Life Cycle Hooks for ASG: ' + asg_name)
    hookname=asg_name + '-life-cycle-launch'
    try:
        asg.delete_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name)
    except Exception as e:
        logger.info("[ASG life-cycle Hook Launch]: {}".format(e))
    hookname=asg_name + '-life-cycle-terminate'
    try:
        asg.delete_lifecycle_hook(LifecycleHookName=hookname, AutoScalingGroupName=asg_name)
    except Exception as e:
        logger.info("[ASG life-cycle Hook Terminate]: {}".format(e))
    return

def remove_asg_vms(stackname, asg_grp_name, KeyPANWPanorama, delete_stack):
    """

    :param stackname:
    :param :asg_grp_name:
    :param :KeyPANWPanorama:
    :param :delete_stack:
    :return:
    """
    response=asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_grp_name])
   
    # Initiate removal of all EC2 instances associated to ASG
    found = False
    for i in response['AutoScalingGroups']:
        for ec2i in i['Instances']:
            found = True
            logger.info('Terminating instance: ' + ec2i['InstanceId'] + ' HealthStatus: ' + ec2i['HealthStatus'])
            logger.info(ec2i)

            release_eip(stackname, ec2i['InstanceId'])

            try:
                ec2_client.terminate_instances(InstanceIds=[ec2i['InstanceId']])
            except Exception as e:
                logger.warning("[Terminate Instance in ASG]: {}".format(e))
    
    return found

def common_alarm_func_del(alarmname):
    """

    :param alarmname:
    :return:
    """
    a1=alarmname + '-high'
    logger.info('Removing Alarm Name: ' + alarmname + ' High: ' + a1)
    try:
       cloudwatch.delete_alarms(AlarmNames=[a1])
    except Exception as e:
       a1=alarmname + '-low'

    a1=alarmname + '-low'
    try:
        cloudwatch.delete_alarms(AlarmNames=[a1])
    except Exception as e:
       return

    return

def remove_alarm(asg_name):
    """

    :param asg_name:
    :return:
    """
    alarmname= asg_name + '-cw-cpu'
    common_alarm_func_del(alarmname)

    alarmname= asg_name + '-cw-as'
    common_alarm_func_del(alarmname)

    alarmname= asg_name + '-cw-su'
    common_alarm_func_del(alarmname)

    alarmname= asg_name + '-cw-gpu'
    common_alarm_func_del(alarmname)

    alarmname= asg_name + '-cw-gpat'
    common_alarm_func_del(alarmname)

    alarmname= asg_name + '-cw-dpb'
    common_alarm_func_del(alarmname)

    alarmname= asg_name + '-cw-sspu'
    common_alarm_func_del(alarmname)

    return

def scalein_asg(stackname, elbtg):
    asg_grp_name=get_asg_name(stackname, elbtg)
    try:
        logger.info('Disable metrics collection and Set Min and Desired Capacity to 0 for ASG: ' + asg_grp_name)
        asg.disable_metrics_collection(AutoScalingGroupName=asg_grp_name)
        asg.update_auto_scaling_group(AutoScalingGroupName=asg_grp_name, MinSize=0, DesiredCapacity=0, DefaultCooldown=0)
    except Exception as e:
         logger.info('Could not disable_metrics_collection and Set Min/Desired Capacity to 0 for ASG. Reason below')
         logger.info("[RESPONSE]: {}".format(e))
         return False

    return True


def remove_asg(stackname, elbtg, ScalingParameter, KeyPANWPanorama, force, delete_stack):
    """

    :param stackname:
    :param elbtg:
    :param ScalingParameter:
    :param KeyPANWPanorama:
    :param force:
    :param delete_stack:
    :return:
    """
    asg_grp_name=get_asg_name(stackname, elbtg)

    logger.info('Remove ASG: ' + asg_grp_name)

    try:
        logger.info('Disable metrics collection and Set Min and Desired Capacity to 0 for ASG: ' + asg_grp_name)
        asg.disable_metrics_collection(AutoScalingGroupName=asg_grp_name)
        scaleout=asg_grp_name + '-scaleout'
        asg.update_auto_scaling_group(AutoScalingGroupName=asg_grp_name, MinSize=0, DesiredCapacity=0)
        #asg.put_scheduled_update_group_action(AutoScalingGroupName=asg_grp_name, ScheduledActionName=scaleout, MinSize=0, DesiredCapacity=0)
    except Exception as e:
         logger.info('Could not disable_metrics_collection and Set Min/Desired Capacity to 0 for ASG. Reason below')
         logger.info("[RESPONSE]: {}".format(e))
         if force == False:
             remove_alarm(asg_grp_name)
             return False

    remove_alarm(asg_grp_name)

    policyname=asg_grp_name + '-scalein'
    logger.info('Deleting ScalePolicyIn :' + policyname)
    try:
        asg.delete_policy(AutoScalingGroupName=asg_grp_name, PolicyName=policyname)
    except Exception as e:
         logger.info("[ScaleIn Policy]: {}".format(e))

    policyname=asg_grp_name + '-scaleout'

    logger.info('Deleting ScalePolicyOut :' + policyname)
    try:
        asg.delete_policy(AutoScalingGroupName=asg_grp_name, PolicyName=policyname)
    except Exception as e:
         logger.info("[ScaleOut Policy]: {}".format(e))

    if remove_asg_vms(stackname, asg_grp_name, KeyPANWPanorama, delete_stack) == True:
        if force == False:
            return False

    remove_asg_life_cycle(asg_grp_name)

    logger.info('Deleting ASG : ' + asg_grp_name)
    try:
        if force == True:
            asg.delete_auto_scaling_group(AutoScalingGroupName=asg_grp_name, ForceDelete=True)
        else:
            asg.delete_auto_scaling_group(AutoScalingGroupName=asg_grp_name)
    except Exception as e:
         logger.info('Could not remove ASG. Reason below')
         logger.error("[ASG DELETE]: {}".format(e))
         if force == False:
             return False

    return True

def read_s3_object(bucket, key):
    """
    :param bucket:
    :param key:
    :return:
    """
    # Get the object from the event and show its content type
    key = unquote_plus(key)
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        print("CONTENT TYPE: " + response['ContentType'])
        contents=response['Body'].read().decode('utf-8')
        #print('Body: ' + str(contents))
        return str(contents)
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist.'.format(key, bucket))
        return None

def get_values_from_init_cfg(contents):
    """
    Retrieve the keys from the init-cfg file
    :param contents:
    :return: dict
    """
    d = {'panorama-server': "", 'tplname': "", 'dgname': "", 'hostname': ""}
    if contents is None:
        return d

    contents=contents.replace('\n', '::')
    list=contents.split("::")
    for i in list:
        if i == "":
            continue

        s=i.split("=")
        if s[0] != "" and s[0] == "panorama-server" and s[1] != "":
            d['panorama-server']=s[1]
        elif s[0] != "" and s[0] == "tplname" and s[1] != "":
            d['tplname']=s[1]
        elif s[0] != "" and s[0] == "dgname" and s[1] != "":
            d['dgname']=s[1]
        elif s[0] != "" and s[0] == "hostname" and s[1] != "":
            d['hostname']=s[1]

    return d


def panorama_remove_serial_and_ip(stackname, r, pdict):
    """

    :param stackname:
    :param r:
    :param pdict:
    :return:
    """
    if pdict is None:
        return

    BootstrapS3Bucket=r['BootstrapS3Bucket']
    c=read_s3_object(BootstrapS3Bucket, "config/init-cfg.txt")
    dict = get_values_from_init_cfg(c)
    logger.info('Panorama: Init CFG bootstrap file Panorama settings is as follows: ')
    logger.info(dict)

    PanoramaIP=dict['panorama-server']
    PanoramaDG=dict['dgname']
    PanoramaTPL=dict['tplname']

    KeyPANWPanorama=r['KeyPANWPanorama']

    if PanoramaIP == "":
        return None

    cnt=len(pdict)
    for i in pdict:
        print(i)

    return

def panorama_save_serial_and_ip(stackname, r):
    """

    :param stackname:
    :param r:
    :return:
    """
    pdict = []

    BootstrapS3Bucket=r['BootstrapS3Bucket']
    c=read_s3_object(BootstrapS3Bucket, "config/init-cfg.txt")
    dict = get_values_from_init_cfg(c)
    logger.info('Panorama: Init CFG bootstrap file Panorama settings is as follows: ')
    logger.info(dict)

    PanoramaIP=dict['panorama-server']
    PanoramaDG=dict['dgname']
    PanoramaTPL=dict['tplname']

    KeyPANWPanorama=r['KeyPANWPanorama']
    elb_name=r['ELBName']

    if PanoramaIP == "":
        return None

    response = elb.describe_instance_health(LoadBalancerName=elb_name)
    for i in response['InstanceStates']:
        instanceId=i['InstanceId']
        iresponse=ec2_client.describe_network_interfaces(Filters=[{'Name': "attachment.instance-id", 'Values': [str(instanceId)]}])
        gwMgmtIp=""
        for ir in iresponse['NetworkInterfaces']:
            eniId=ir['NetworkInterfaceId']
            Attachment=ir['Attachment']
            aId=Attachment['AttachmentId']
            if Attachment['DeviceIndex'] == 1:
                gwMgmtIp=ir['PrivateIpAddress']
                break

        if gwMgmtIp is not None:
            serial_no=remove_device(stackname, False, PanoramaIP, KeyPANWPanorama, PanoramaDG, PanoramaTPL, "", gwMgmtIp)
            if serial_no is not None and serial_no != "Done":
                d = {'IP': gwMgmtIp, 'SerialNo': serial_no}
                pdict.append(d)

    print('Items for Panorama are as follows:')
    print(pdict)
    return pdict


def retrieve_asg_instances(asg_name):
    """

    :param asg_name:
    :return: list of instanceIds
    """
    instance_list = []
    response=asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
    for i in response['AutoScalingGroups']:
        for ec2i in i['Instances']:
            instanceId=ec2i['InstanceId']
            instance_list.append(instanceId)
    logger.info('List of instances in ASG {}: {}'.format(asg_name, instance_list))
    return instance_list


def panorama_delete_stack(bsS3Bucket, instance_list, keyPanoramam, stackname, region):
    """

    :param bsS3Bucket:
    :param asg_name:
    :param keyPanoramam:
    :return:
    """
    c=read_s3_object(bsS3Bucket, "config/init-cfg.txt")
    dict = get_values_from_init_cfg(c)
    logger.info('Panorama: Init CFG bootstrap file Panorama settings is as follows: ')
    logger.info(dict)

    PanoramaIP=dict['panorama-server']
    PanoramaDG=dict['dgname']
    PanoramaTPL=dict['tplname']

    if PanoramaIP == "":
        return

    #response=asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
   
    # Initiate removal of all EC2 instances associated to ASG
    #found = False
    #for i in response['AutoScalingGroups']:
    #    for ec2i in i['Instances']:
    #        instanceId=ec2i['InstanceId']

    # Remove all instances
    for instanceId in instance_list:
        response = firewall_table_get_instance(stackname, region, instanceId)
        if response:
            for fw in response['Items']:
                # Should only have a single firewall in response
                gwMgmtIp=''
                try:
                    gwMgmtIp=fw['MgmtPrivIP']
                except:
                    logger.error('Firewall IP could not be found. Can not remove it from Panorama')
                    return
                else:
                    logger.info('Firewall IP: {}. Removing from Panorama'.format(gwMgmtIp))

                logger.info('Panorama: Removing instance {} from Panorama Device.'.format(instanceId))
                remove_fw_from_panorama(instanceId, keyPanoramam, gwMgmtIp, PanoramaIP, PanoramaDG, PanoramaTPL)
    return

def delete_asg_stack(stackname, region, elbtg, bsS3Bucket, ScalingParameter, keyPanoramam, force, subnet_ids):
    """

    :param stackname:
    :param elbtg:
    :param bsS3Bucket:
    :param ScalingParameter:
    :param KeyPANWPanorama:
    :param force:
    :param subnet_ids:
    :return:
    """
    found = False


    asg_name = get_asg_name(stackname, elbtg)
    asg_response=asg.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
    print(asg_response)
    if len(asg_response['AutoScalingGroups']) != 0:
        found = True
        logger.info('Delete asg : ' + asg_name)

        ok = remove_asg(stackname, elbtg, ScalingParameter, keyPanoramam, force, True)

        if not ok:
            logger.warning("An error occurred during removal of ASG {}, and the force flag was not set.".format(asg_name))

    return found

#
# Lambda ENIs when deployed in NAT Gateway mode don't go away (because of VPCconfig)
#
def delete_eni_lambda(vpc_sg):
    """

    :param vpc_sg:
    :return:
    """
    print('Look for ENIs in Lambda VPC SG: ' + vpc_sg)
    response=ec2_client.describe_network_interfaces(Filters=[{'Name': "group-id", 'Values': [str(vpc_sg)]}])
    print(response)
    good=True
    for i in response['NetworkInterfaces']:
        eniId=i['NetworkInterfaceId']
        if i['Status'] == "available":
            try:
                ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
            except Exception as e:
                logger.warning("[Lambda delete Eni]: {}".format(e))
                good=False
            continue

        Attachment=i['Attachment']
        aId=Attachment['AttachmentId']
        print('Detaching Eni ID: ' + eniId + ' Desc: ' + i['Description'] + ' IP: ' + i['PrivateIpAddress'] + ' AZ: ' + i['AvailabilityZone'])
        print('Detaching Attachment ID: ' + aId + ' DeviceIndex: ' +  str(Attachment['DeviceIndex']))
        if Attachment['DeviceIndex'] != 0:
            try:
                ec2_client.modify_network_interface_attribute(NetworkInterfaceId=eniId,
                           Attachment={ 'AttachmentId': aId, 'DeleteOnTermination': True})
                ec2_client.detach_network_interface(AttachmentId=aId, Force=True)
                ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
            except Exception as e:
                good=False
                logger.warning("[Lambda detach Eni]: {}".format(e))
                try:
                    ec2_client.delete_network_interface(NetworkInterfaceId=eniId)
                except Exception as e:
                    logger.warning("[Lambda delete Eni in modify/delete]: {}".format(e))

    return good


def delete_asg_stacks(stackname, region, elbtg, vpc_sg, bsS3Bucket, ScalingParameter, KeyPANWPanorama, subnet_ids):
    """

    :param stackname:
    :param region:
    :param elbtg:
    :param vpc_sg:
    :param bsS3Bucket:
    :param ScalingParameter:
    :param KeyPANWPanorama:
    :param subnet_ids:
    :return:
    """
    force=False

    # Retrieve instances in ASG for Panorama de-registration later.  This operation must
    # be done prior to removal of the ASG.
    asg_name = get_asg_name(stackname, elbtg)
    instance_list = retrieve_asg_instances(asg_name)

    for i in range(1,90):
        logger.info('Attempting to Delete ASGs Iteration: ' + str(i))
        if i >= 2:
            force=True
            try:
                print('Delete ENI for Lambda with VPC SG if any...')
                delete_eni_lambda(vpc_sg)
            except Exception as e:
                 logger.warning("[delete ENI lambda]: {}".format(e))

        if delete_asg_stack(stackname, region, elbtg, bsS3Bucket, ScalingParameter, KeyPANWPanorama, force, subnet_ids) == False:
            logger.info('DONE with deleting ASGs')
            break
        time.sleep(1)

    # ASG has been removed, attempt to remove instances from Panorama.
    # Wait some time to allow terminated instances to go to disconnected state.
    time.sleep(60)
    try:
        panorama_delete_stack(bsS3Bucket, instance_list, KeyPANWPanorama, stackname, region)
    except Exception as e:
        logger.warning("[Delete Device from Panorama]: {}".format(e))

    try:
        delete_eni_lambda(vpc_sg)
        for iter in range(1,30):
            print('Delete ENI for Lambda with VPC SG if any: Iteration: ' + str(iter))
            if delete_eni_lambda(vpc_sg) == True:
                break
            time.sleep(1)
    except Exception as e:
        logger.error("[Delete eni lambda]: {}".format(e))
        logger.error("You may have some left-over resource which you will have to delete manually")

    return

def getAccountId(rid):
    """

    :param rid:
    :return:
    """
    try:
        list=rid.split(":")
        return list[4]
    except Exception as e:
        return None

def getRegion(rid):
    """

    :param rid:
    :return:
    """
    try:
        list=rid.split(":")
        return list[3]
    except Exception as e:
        return None

def getSqs(stackname, region, account):
    """

    :param stackname:
    :param region:
    :param account:
    :return:
    """
    try:
        queue_url="https://"+region+".queue.amazonaws.com/"+account+"/"+stackname
        #print('getSqs Queue is: ' + queue_url)
        response=sqs.receive_message(QueueUrl=queue_url, MaxNumberOfMessages=10)
        print(response)
        str=""
        for m in response['Messages']:
            body=m['Body']
            if str == "":
                str=body
            else:
                str=str+":"+body

        print(str)
        return str
    except Exception as e:
         return None
    return None

def getSqsMessages(stackname, account):
    """

    :param stackname:
    :param account:
    :return:
    """
    region=getRegion(account)
    if region is None:
        return None

    id=getAccountId(account)
    msg=getSqs(stackname, region, id)
    return msg

def getDebugLevelFromMsg(msg):
    """

    :param msg:
    :return:
    """
    #print('Message is 1: ' + msg)
    list=msg.split(":")
    for i in list:
        ilist=i.split("=")
        name=ilist[0]
        value=ilist[1]
        if name == "logger":
            return value

def setDebugLevelFromMsg(logger, lvl):
    """

    :param logger:
    :param lvl:
    :return:
    """
    #print('Setting lvl to: ' + lvl)
    if lvl is None:
        logger.setLevel(logging.WARNING)
    elif lvl == "DEBUG":
        logger.setLevel(logging.DEBUG)
    elif lvl == "INFO":
        logger.setLevel(logging.INFO)
    elif lvl == "WARNING":
        logger.setLevel(logging.WARNING)
    elif lvl == "ERROR":
        logger.setLevel(logging.ERROR)
    elif lvl == "CRITICAL":
        logger.setLevel(logging.CRITICAL)

def getDebugLevel(stackname, region, account):
    """

    :param stackname:
    :param region:
    :param account:
    :return:
    """
    try:
        queue_url="https://"+region+".queue.amazonaws.com/"+account+"/"+stackname
        #print('Queue Name is : ' + queue_url)
        response=sqs.receive_message(QueueUrl=queue_url, MaxNumberOfMessages=10)
        #print(response)
        for m in response['Messages']:
            body=m['Body']
            list=body.split(":")
            for i in list:
                ilist=i.split("=")
                name=ilist[0]
                value=ilist[1]
                if name == "logger":
                    return value
    except Exception as e:
         return None

def setLoggerLevel(logger, stackname, account):
    """

    :param logger:
    :param stackname:
    :param account:
    :return:
    """
    region=getRegion(account)
    if region is None:
        return None

    id=getAccountId(account)
    lvl=getDebugLevel(stackname, region, id)

    if lvl is None:
        logger.setLevel(logging.WARNING)
    elif lvl == "DEBUG":
        logger.setLevel(logging.DEBUG)
    elif lvl == "INFO":
        logger.setLevel(logging.INFO)
    elif lvl == "WARNING":
        logger.setLevel(logging.WARNING)
    elif lvl == "ERROR":
        logger.setLevel(logging.ERROR)
    elif lvl == "CRITICAL":
        logger.setLevel(logging.CRITICAL)

def getScalingValue(msg, ScalingParameter):
    """

    :param msg:
    :param ScalingParameter:
    :return:
    """
    print('getScalingValue()...')
    print(msg)
    try:
        list=msg.split(":")
        for i in list:
           ilist=i.split("=")
           name=ilist[0]
           value=ilist[1]
           print('Name: ' + name + ' Value: ' + value)
           if name == "ActiveSessions" and ScalingParameter == "ActiveSessions":
               return float(value)
           elif name == "DataPlaneCPUUtilization" and ScalingParameter == "DataPlaneCPUUtilization":
               return float(value)
           elif name == "SessionUtilization" and ScalingParameter == "SessionUtilization":
               return float(value)
           elif name == "GPGatewayUtilization" and ScalingParameter == "GPGatewayUtilization":
               return float(value)
           elif name == "DataPlaneBufferUtilization" and ScalingParameter == "DataPlaneBufferUtilization":
               return float(value)
    except Exception as e:
         return None

    return None

def getUntrustIP(instanceid, untrust):
    """

    :param instanceid:
    :param untrust:
    :return:
    """
    logger.info('Getting IP address of Untrust Interface for instance: ' + instanceid)
    ip=""
    found=False
    response=ec2_client.describe_instances(InstanceIds=[instanceid])
    logger.info(response)
    for r in response['Reservations']:
        for i in r['Instances']:
            for s in i['NetworkInterfaces']:
                 if s['SubnetId'] == untrust:
                     found=True
                     ip=s['PrivateIpAddress']
                     break

        if found == True:
            break

    if found == True:
        return ip

    return None

def getAzs(subnet_ids):
    """
    
    :param subnet_ids:
    :return:
    """
    fw_azs = []
    subnetids=subnet_ids.split(',')
    for i in subnetids:
        subnet=ec2.Subnet(i)
        fw_azs.append(subnet.availability_zone)
    return fw_azs

def delete_table(tablename):
    """
    
    :param tablename:
    :return:
    """
    dynamodb = boto3.client('dynamodb')

    try:
        dynamodb.delete_table(TableName=tablename)
        return True
    except Exception as e:
        logger.error("[Delete DynamoDB Table]: {}".format(e))
        return False

def create_firewall_table(stack_name, region):
    """

    :param stack_name:
    :param region:
    :return:
    """

    table_name=get_firewall_table_name(stack_name, region)

    try:
        response = dynamodb.create_table(
            AttributeDefinitions=[
                {
                    'AttributeName': 'InstanceID',
                    'AttributeType': 'S'
                },
                {
                    'AttributeName': 'InstanceState',
                    'AttributeType': 'S'
                },
            ],
            TableName=table_name,
            KeySchema=[
                {
                    'AttributeName': 'InstanceID',
                    'KeyType': 'HASH'
                },
            ],
            GlobalSecondaryIndexes=[
                {
                    'IndexName': 'StateIndex',
                    'KeySchema': [
                        {
                            'AttributeName': 'InstanceState',
                            'KeyType': 'HASH'
                        },
                    ],
                    'Projection': {
                        'ProjectionType': 'ALL',
                    },
                    'ProvisionedThroughput': {
                        'ReadCapacityUnits': 10,
                        'WriteCapacityUnits': 10
                    }
                },
            ],
            StreamSpecification={
                'StreamEnabled': True,
                'StreamViewType': 'NEW_AND_OLD_IMAGES'
            },
            ProvisionedThroughput={
                'ReadCapacityUnits': 10,
                'WriteCapacityUnits': 10
            }
        )
        #logger.info("Table status: %s", response['TableDescription']['TableStatus'])
        return True

    except Exception as e:
        logger.error("[Create DynamoDB Table]: {}".format(e))
        return False


def create_nlb_table(stack_name, region):
    """

    :param stack_name:
    :param region:
    :return:
    """
    table_name=get_nlb_table_name(stack_name, region)
    try:
        response = dynamodb.create_table(
            AttributeDefinitions=[
                {
                    'AttributeName': 'TCPPort',
                    'AttributeType': 'N'
                },
                {
                    'AttributeName': 'ILBState',
                    'AttributeType': 'S'
                },
                {
                    'AttributeName': 'Sort',
                    'AttributeType': 'S'
                },
                {
                    'AttributeName': 'DNSName',
                    'AttributeType': 'S'
                },                
                {
                    'AttributeName': 'ILBType',
                    'AttributeType': 'S'
                },                
            ],
            TableName=table_name,
            KeySchema=[
                {
                    'AttributeName': 'DNSName',
                    'KeyType': 'HASH'
                },
            ],
            GlobalSecondaryIndexes=[
                {
                    'IndexName': 'SortIndex',
                    'KeySchema': [
                        {
                            'AttributeName': 'Sort',
                            'KeyType': 'HASH'
                        },
                        {
                            'AttributeName': 'TCPPort',
                            'KeyType': 'RANGE'
                        },
                    ],
                    'Projection': {
                        'ProjectionType': 'ALL',
                    },
                    'ProvisionedThroughput': {
                        'ReadCapacityUnits': 10,
                        'WriteCapacityUnits': 10
                    }
                },
                {
                    'IndexName': 'StateIndex',
                    'KeySchema': [
                        {
                            'AttributeName': 'ILBState',
                            'KeyType': 'HASH'
                        },
                    ],
                    'Projection': {
                        'ProjectionType': 'ALL',
                    },
                    'ProvisionedThroughput': {
                        'ReadCapacityUnits': 10,
                        'WriteCapacityUnits': 10
                    }
                },
                {   
                    'IndexName': 'DNSNameIndex',
                    'KeySchema': [
                        {   
                            'AttributeName': 'DNSName',
                            'KeyType': 'HASH'
                        },
                    ],
                    'Projection': {
                        'ProjectionType': 'ALL',
                    },
                    'ProvisionedThroughput': {
                        'ReadCapacityUnits': 10,
                        'WriteCapacityUnits': 10
                    }
                },                
                {   
                    'IndexName': 'ILBTypeIndex',
                    'KeySchema': [
                        {   
                            'AttributeName': 'ILBType',
                            'KeyType': 'HASH'
                        },
                    ],
                    'Projection': {
                        'ProjectionType': 'ALL',
                    },
                    'ProvisionedThroughput': {
                        'ReadCapacityUnits': 10,
                        'WriteCapacityUnits': 10
                    }
                },                
            ],
            StreamSpecification={
                'StreamEnabled': True,
                'StreamViewType': 'NEW_AND_OLD_IMAGES'
            },
            ProvisionedThroughput={
                'ReadCapacityUnits': 10,
                'WriteCapacityUnits': 10
            }
        )
        #logger.info("Table status: %s", response['TableDescription']['TableStatus'])
        return True

    except Exception as e:
        logger.exception("[Create DynamoDB Table]: {}".format(e))
        return False
def nlb_table_add_entry(stack_name, region, port, nlb_state, SubnetAzdata1, SubnetAzdata2, SubnetAzdata3, SubnetAzdata4, dns_name, nlb_name, vpc_peerconn_id, vpc_id, ilb_type, vpc_cidr=None ):
    """

    :param stack_name:
    :param region:
    :param port:
    :param nlb_state:
    :param dns_name:
    :param nlb_name:
    :param vpc_peerconn_id:
    :param nlb_subnet_cidr:
    :param AZdetails    
    :return:
    """

    if not vpc_cidr:
        response = ec2_client.describe_vpcs(VpcIds=[vpc_id])
        for r in response['Vpcs']:
            vpc_cidr= r['CidrBlock']

    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.put_item(
            Item={
                    'TCPPort':int(port),
                    'ILBState': nlb_state,
                    'Sort':'OK',
                    'Subnet-CIDR-AZ1': SubnetAzdata1,
                    'Subnet-CIDR-AZ2': SubnetAzdata2,
                    'Subnet-CIDR-AZ3': SubnetAzdata3,
                    'Subnet-CIDR-AZ4': SubnetAzdata4,
                    'DNSName': dns_name,
                    'ILBName': nlb_name,
                    'VPCPeerConnID':vpc_peerconn_id,
                    'VPCID' :vpc_id,
                    'ILBType' :ilb_type,
                    'VPCCidr' :vpc_cidr,
            }
        )
        return True
    except Exception as e:
        logger.exception("[ILB Table add entry error]: {}".format(e))
        return False



def nlb_table_delete_entry(stack_name, region, dns_name):
    """

    :param stack_name:
    :param region:
    :param nlb_ip:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.delete_item(
            Key={
                    'DNSName': dns_name,
            }
        )
        return True
    except Exception as e:
        logger.exception("[ILB Table delete entry error]: {}".format(e))
        return False

def nlb_table_delete_entry_by_dnsname(stack_name, region, dns_name):
    """

    :param stack_name:
    :param region:
    :param dns_name:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.query(IndexName='DNSNameIndex',
            KeyConditionExpression=Key('DNSName').eq(dns_name),
            ScanIndexForward=False)
        if response['Count'] != 0:
            for i in response['Items']:
                del_resp = table.delete_item(
                    Key={
                        'DNSName': i['DNSName'],
                    }
                )
                if del_resp['ResponseMetadata']['HTTPStatusCode'] != 200:
                    logger.exception('[ILB Table delete entry failed with error code]: {}'.format(del_resp['ResponseMetadata']['HTTPStatusCode']))
                    return False
        return True
    except Exception as e:
        logger.exception("[ILB Table delete entry by DNS name error]: {}".format(e))
        return False

def nlb_table_get_entry_by_dnsname(stack_name, region, dns_name):
    """

    :param stack_name:
    :param region:
    :param dns_name:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.query(IndexName='DNSNameIndex',
            KeyConditionExpression=Key('DNSName').eq(dns_name),
            ScanIndexForward=False)
        return response
    except Exception as e:
        logger.exception("[ILB Table get entry by DNS name error]: {}".format(e))
        return None

def nlb_table_update_state(stack_name, region, dns_name, nlb_state):
    """

    :param stack_name:
    :param region:
    :param dns_name:
    :param nlb_state:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.update_item(
            Key={'DNSName': dns_name},
            UpdateExpression="SET ILBState = :s",
            ExpressionAttributeValues={ ':s': nlb_state, }
        )
        return True
    except Exception as e:
        logger.exception("[ILB Table update state error]: {}".format(e))
        return False


def nlb_table_get_from_db(stack_name, region, dns_name):
    """

    :param stack_name:
    :param region:
    :param dns_name:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.query(
            KeyConditionExpression=Key('DNSName').eq(dns_name)
        )
        return response
    except Exception as e:
        logger.exception("[ILB Table get from db error]: {}".format(e))
        return None

def nlb_table_get_next_avail_port(stack_name, region):
    """

    :param stack_name:
    :param region:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.query(IndexName='SortIndex',
            KeyConditionExpression=Key('Sort').eq('OK'),
            ScanIndexForward=False)
        if response['Count'] == 0:
            return start_nlb_port
        if response['Items'][0]['TCPPort'] < num_nlb_port+start_nlb_port-1:
            return response['Items'][0]['TCPPort']+1
        else:
            response=table.query(IndexName='SortIndex',
                KeyConditionExpression=Key('Sort').eq('OK'))
            for i in range(start_nlb_port, num_nlb_port+start_nlb_port-1):
                for k in response['Items']:
                    if i == k['TCPPort']:
                        break
                    if i < k['TCPPort']:
                        return i
    except Exception as e:
        logger.exception("[ILB Table get next avail port error]: {}".format(e))

    return 0

def nlb_table_get_all_in_state(stack_name, region, state):
    """

    :param stack_name:
    :param region:
    :param state:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.query(IndexName='StateIndex',
            KeyConditionExpression=Key('ILBState').eq(state),
            ScanIndexForward=False)
        return response
    except Exception as e:
        logger.exception("[ILB Table get all in state error]: {}".format(e))
        return None
        
def nlb_table_get_all_alb(stack_name, region):
    """

    :param stack_name:
    :param region:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.query(IndexName='ILBTypeIndex',
            KeyConditionExpression=Key('ILBType').eq('ALB'),
            ScanIndexForward=False)
        return response
    except Exception as e:
        logger.exception("[ILB Table get all ALB error]: {}".format(e))
        return None
        
def firewall_table_add_instance(stack_name, region, instance_id, state, term_state, asg_name, ip, pip, untrust_ip):
    """

    :param stack_name:
    :param region:
    :param instance_id:
    :param state:
    :param term_state:
    :param asg_name:
    :param ip:
    :param pip:
    :param untrust_ip:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.put_item(
            Item={
                    'InstanceID': instance_id,
                    'InstanceState': state,
                    'AsgName': asg_name,
                    'MgmtIP': ip,
                    'MgmtPrivIP': pip,
                    'UntrustIP': untrust_ip,
                    'ListILBPorts': 'None',
                    'iLBRuleMask0': hex(0),
                    'iLBRuleMask1': hex(0),
                    'iLBRuleMask2': hex(0),
                    'iLBRuleMask3': hex(0),
                    'iLBRuleMask4': hex(0),
                    'iLBRuleMask5': hex(0),
                    'iLBRuleMask6': hex(0),
                    'iLBRuleMask7': hex(0),
                    'iLBRuleMask8': hex(0),
                    'iLBRuleMask9': hex(0),
                    'iLBRuleMask10': hex(0),
                    'iLBRuleMask11': hex(0),
                    'iLBRuleMask12': hex(0),
                    'iLBRuleMask13': hex(0),
                    'iLBRuleMask14': hex(0),
                    'iLBRuleMask15': hex(0),
                    'iLBRuleMask16': hex(0),
                    'iLBRuleMask17': hex(0),
                    'iLBRuleMask18': hex(0),
                    'iLBRuleMask19': hex(0)
            }
        )
        return True
    except Exception as e:
        logger.exception("[FW Table add instance error]: {}".format(e))
        return False



def firewall_table_update_state(stack_name, region, instance_id, state):
    """

    :param stack_name:
    :param region:
    :param instance_id:
    :param state:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.update_item(
            Key={'InstanceID': instance_id},
            UpdateExpression="SET InstanceState = :s",
            ExpressionAttributeValues={ ':s': state, }
        )
        return True
    except Exception as e:
        logger.exception("[FW Table update state error]: {}".format(e))
        return False

def firewall_table_update_rule_mask(stack_name, region, instance_id, rule_mask):
    """

    :param stack_name:
    :param region:
    :param instance_id:
    :param rule_mask:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        ports=''
        for index in range(len(rule_mask)):
            for bit in range(64):
                if (rule_mask[index] & 1<<bit) != 0:
                    ports += str(64*index+bit+start_nlb_port)+','
        if not ports:
            ports = 'None'
        else:
            ports = ports[:-1]
        response = table.update_item(
            Key={'InstanceID': instance_id},
            UpdateExpression='SET iLBRuleMask0=:0, iLBRuleMask1=:1, iLBRuleMask2=:2, iLBRuleMask3=:3, iLBRuleMask4=:4, iLBRuleMask5=:5, iLBRuleMask6=:6,'+
                                'iLBRuleMask7=:7, iLBRuleMask8=:8, iLBRuleMask9=:9, iLBRuleMask10=:10,iLBRuleMask11=:11,iLBRuleMask12=:12, iLBRuleMask13=:13,'+
                                'iLBRuleMask14=:14, iLBRuleMask15=:15,iLBRuleMask16=:16,iLBRuleMask17=:17,iLBRuleMask18=:18,iLBRuleMask19=:19,ListILBPorts=:20',
            ExpressionAttributeValues={ ':0': hex(rule_mask[0]), ':1': hex(rule_mask[1]), ':2': hex(rule_mask[2]), ':3': hex(rule_mask[3]), ':4': hex(rule_mask[4]),
                                ':5': hex(rule_mask[5]), ':6': hex(rule_mask[6]), ':7': hex(rule_mask[7]), ':8': hex(rule_mask[8]), ':9': hex(rule_mask[9]),
                                ':10': hex(rule_mask[10]), ':11': hex(rule_mask[11]), ':12': hex(rule_mask[12]), ':13': hex(rule_mask[13]), ':14': hex(rule_mask[14]),
                                ':15': hex(rule_mask[15]), ':16': hex(rule_mask[16]), ':17': hex(rule_mask[17]), ':18': hex(rule_mask[18]), ':19': hex(rule_mask[19]),
                                ':20': ports
            }
        )
        return True
    except Exception as e:
        logger.exception("[FW Table update rule mask error]: {}".format(e))
        return False


def firewall_table_get_from_db(stack_name, region, instance_id):
    """

    :param stack_name:
    :param region:
    :param instance_id:
    :return:
    """
    try:
        table_name=get_nlb_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.query(
            KeyConditionExpression=Key('InstanceID').eq(instance_id)
        )
        return response
    except Exception as e:
        logger.exception("[FW Table get from db error]: {}".format(e))
        return None

def firewall_table_delete_instance1(stack_name, region, instance_id):
    """

    :param stack_name:
    :param region:
    :param instance_id:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.query(
            KeyConditionExpression=Key('InstanceID').eq(instance_id)
        )
        if response['Count'] != 0:
            state = response['Items'][0]['InstanceState']
            response = table.delete_item(
                Key={
                        'InstanceID': instance_id,
                        'InstanceState': state
                }
            )
        return True
    except Exception as e:
        logger.exception("[FW Table detele instance error]: {}".format(e))
        return False

def firewall_table_delete_instance(stack_name, region, instance_id):
    """

    :param stack_name:
    :param region:
    :param instance_id:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response = table.delete_item(
            Key={
                    'InstanceID': instance_id,
            }
        )
        return True
    except Exception as e:
        logger.exception("[FW Table delete instance error]: {}".format(e))
        return False

def firewall_table_get_all_in_az_state(stack_name, region, state, avail_zone):
    """

    :param stack_name:
    :param region:
    :param state:
    :param avail_zone:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.query(IndexName='StateIndex',
            KeyConditionExpression=Key('InstanceState').eq(state) & Key('AvailZone').eq(avail_zone),
            ScanIndexForward=False)
        return response
    except Exception as e:
        logger.exception("[FW Table get all in az state error]: {}".format(e))
        return None

def firewall_table_get_all_in_state(stack_name, region, state):
    """
        
    :param stack_name:
    :param region:
    :param state:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.query(IndexName='StateIndex',
            KeyConditionExpression=Key('InstanceState').eq(state),
            ScanIndexForward=False)
        return response
    except Exception as e:
        logger.exception("[FW Table get all in state error]: {}".format(e))
        return None

def firewall_table_get_all_instances(stack_name, region):
    """
        
    :param stack_name:
    :param region:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.scan()
        return response
    except Exception as e:
        logger.exception("[FW Table get all instances error]: {}".format(e))
        return None

def firewall_table_get_instance(stack_name, region, instanceid):
    """
        
    :param stack_name:
    :param region:
    :return:
    """
    try:
        table_name=get_firewall_table_name(stack_name, region)
        table=dynamodb.Table(table_name)
        response=table.query(KeyConditionExpression=Key('InstanceID').eq(instanceid))
        return response
    except Exception as e:
        logger.exception("[FW Table get instance error]: {}".format(e))
        return None

remote=0

def firewall_table_update_serial_no(stack_name, region, instance_id, serial_no):
    """
    Update the serial_no column for a firewall instance in dynamodb
 
    :param stack_name:
    :param region:
    :param instance_id:
    :param serial_no:
    :return:
    """
    try:
        table_name = get_firewall_table_name(stack_name, region)
        table = dynamodb.Table(table_name)
        response = table.update_item(
            Key={'InstanceID': instance_id},
            UpdateExpression='SET SerialNo = :s',
            ExpressionAttributeValues={':s': serial_no}
        )
        logger.info('Updated firewall SerialNo in fw table: {}'.format(response))
        return True
    except Exception as e:
        logger.exception('[firewall_table_update_serial_no] ERROR: {}'.format(e))
        return False

def pan_print(s):
    """
        
    :param s:
    :return:
    """
    if remote > 0:
        logger.info(s)
        return
    print(s)
    return

def getChassisReady(response):
    """

    :param response:
    :return:
    """
    s1=response.replace('\n',"")
    s1=s1.replace(" ","")
    if s1.find("<![CDATA[no]]") > 0:
        return False
    if s1.find("<![CDATA[yes]]>") > 0:
        return True
    return False

def getJobStatus(response):
    """

    :param response:
    :return:
    """
    s1=response.replace("/","")
    index=s1.find("<status>")
    list=s1.split("<status>")
    return list[1]

def getJobResult(response):
    """

    :param response:
    :return:
    """
    s1=response.replace("/","")
    index=s1.find("<result>")
    list=s1.split("<result>")
    return list[2]

def getJobTfin(response):
    """

    :param response:
    :return:
    """
    s1=response.replace("/","")
    index=s1.find("<tfin>")
    list=s1.split("<tfin>")
    return list[1]

def getJobProgress(response):
    """

    :param response:
    :return:
    """
    s1=response.replace("/","")
    index=s1.find("<progress>")
    list=s1.split("<progress>")
    return list[1]

def is_firewall_ready(gcontext, gwMgmtIp, api_key):
    """

    :param gcontext:
    :param gwMgmtIp:
    :param api_key:
    :return:
    """
    pan_print('Checking whether Chassis is ready or not')
    cmd="<show><chassis-ready/></show>"
    fw_cmd= "https://"+gwMgmtIp+"/api/?type=op&cmd=" + cmd + "&key="+api_key
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, api_key)
        if response is None:
            pan_print('Failed to run command: ' + fw_cmd)
            return False
        status=getChassisReady(response)
        if status == True:
            pan_print('Chassis is in ready state')
            return True
        else:
            pan_print('Chassis is not ready yet')

        pan_print("[RESPONSE] in send command: {}".format(response))
    except Exception as e:
         logger.error("[AutoCommit RESPONSE]: {}".format(e))

    return False

def is_firewall_auto_commit_done(gcontext, gwMgmtIp, api_key):
    """
    
    :param gcontext:
    :param gwMgmtIp:
    :param api_key:
    :return:
    """
    pan_print('Checking whether AutoCommit is done or not')
    cmd="<show><jobs><id>1</id></jobs></show>"
    fw_cmd= "https://"+gwMgmtIp+"/api/?type=op&cmd=" + cmd + "&key="+api_key
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, api_key)
        if response is None:
            pan_print('Failed to run command: ' + fw_cmd)
            return False
        status=getJobStatus(response)
        if status == "FIN":
            pan_print('AutoCommit is Done')
            pan_print('AutoCommit job status is : ' + getJobStatus(response))
            pan_print('AutoCommit job result is : ' + getJobResult(response))
            pan_print('AutoCommit job tfin is : ' + getJobTfin(response))
            pan_print('AutoCommit job Progress is : ' + getJobProgress(response))
            return True
        else:
            pan_print('AutoCommit is not done or over or failed')
            pan_print('AutoCommit job status is : ' + getJobStatus(response))
            pan_print('AutoCommit job result is : ' + getJobResult(response))
            pan_print('AutoCommit job tfin is : ' + getJobTfin(response))
            pan_print('AutoCommit job Progress is : ' + getJobProgress(response))

        pan_print("[RESPONSE] in send command: {}".format(response))
    except Exception as e:
         logger.error("[AutoCommit RESPONSE]: {}".format(e))

    return False


def config_firewall_init_setting_panorama(panorama_ip,panorama_key,panorama_user,asg_name,temp_name,dg_name):
    """

    :param panorama_ip:
    :param panorama_key:
    :param asg_name:
    :param temp_name:    
    :return:
    """
    pan_print('Set firewall cloudwatch asg name')
    set_xpath = "https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']"
    #1.enable and assign aws-cloud watch
    pan_print('Set firewall cloudwatch asg name')
    # Need this to bypass invalid certificate issue.
    context = get_ssl_context()
    sw_ver = get_panos_version(context, panorama_ip, panorama_key)
    version_nine = False
    if not sw_ver:
        logger.error('FW: Fail to get software version in show system info')
        base_url= set_xpath + "/template-stack/entry[@name='" + temp_name + "']/config/devices/entry[@name='localhost.localdomain']/deviceconfig/setting/aws-cloudwatch"
    else:
        logger.info('Firewall software version: ' + sw_ver)
        if float(sw_ver[:3]) >= float(9.0):
            base_url= set_xpath + "/template-stack/entry[@name='" + temp_name + "']/config/devices/entry[@name='localhost.localdomain']/deviceconfig/plugins/vm_series/aws-cloudwatch"
        else:
            base_url= set_xpath + "/template-stack/entry[@name='" + temp_name + "']/config/devices/entry[@name='localhost.localdomain']/deviceconfig/setting/aws-cloudwatch"

    #url="https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/deviceconfig/setting/aws-cloudwatch"
    url = base_url
    url +="&element=<enabled>yes</enabled>"
    ok, res = execute_command(url)
    logger.info(res)
    if not ok:
        print("Not able to enable the awscloudwatch")
    
    #url="https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/deviceconfig/setting/aws-cloudwatch"
    url = base_url
    url +="&element=<name>"+ asg_name +"</name>"
    ok, res = execute_command(url)
    logger.info(res)
    if not ok:
        logger.info("Not able to setup asgname  in  awscloudwatch")
    
    #url="https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/deviceconfig/setting/aws-cloudwatch"
    url = base_url
    url +="&element=<timeout>5</timeout>"
    ok, res = execute_command(url)
    logger.info(res)
    if not ok:
        logger.info("Not able to setup time interval in  awscloudwatch")

   # 2.Commit the changes locally to panorama
    logger.info("Commit the changes locally to panorama")
    cmd = '<partial><admin><member>{}</member></admin><device-group><member>{}</member></device-group><template-stack><member>{}</member></template-stack></partial>'.format(panorama_user, dg_name, temp_name)
    ok, res = commit_panorama(panorama_ip, panorama_key, cmd)
    if not ok:
        print("Committing changes locally to panorama failed")
    else:
        print("Committing changes locally to panorama succeeded")

    # 3.Commit the changes to DG and TS
    logger.info("Commit the changes to DG and TS")
    cmd = '<commit-all><shared-policy><device-group><entry name="{}"/></device-group><include-template>yes</include-template><merge-with-candidate-cfg>yes</merge-with-candidate-cfg><force-template-values>no</force-template-values><validate-only>no</validate-only></shared-policy></commit-all>'.format(dg_name)
    ok, res = commitall_panorama(panorama_ip, panorama_key, cmd, dg_name)
    if not ok:
        print("Committing changes to DG %s failed" % dg_name)
    else:
        print("Committing changes to DG %s successful" % dg_name)    
    
    
    return True

def get_ipaddress_devices_in_dg(panorama_ip,panorama_key,dg_name):

	# Get ip address of the devices in the dg
    url = "https://" + panorama_ip + "/api/?type=op&key=" + panorama_key
    url += "&cmd=<show><devicegroups><name>"+ dg_name +"</name>"
    url += "</devicegroups></show>"

    ok, res = execute_command(url)
    logger.info (res)
    if not ok:
        logger.info("Not able to get devices ip address")

    ip_list = []
    for dev in  res['devicegroups']['entry']:
        for name in dev['devices']['entry']:
            ip_list.append(name['ip-address'])
    logger.info("List of devices under the DG")
    print("[{0}]".format(', '.join(map(str, ip_list))))
    return ip_list

def get_serialno_disconnected_devices_in_dg(panorama_ip,panorama_key,dg_name):

   # Get ip address of the devices in the dg
        url = "https://" + panorama_ip + "/api/?type=op&key=" + panorama_key
        url += "&cmd=<show><devicegroups><name>"+dg_name+"</name>"
        url += "</devicegroups></show>"

        ok, res = execute_command(url)
        if not ok:
            print("Not able to get devices ip address")

        serial_no_list = []
        for dev in  res['devicegroups']['entry']:
            for name in dev['devices']['entry']:
                connection_status =  name['connected']
                if connection_status == "no":
                    serial_no_list.append(name['serial'])
        return serial_no_list
        
def initial_push_to_device_panorama(panorama_ip,panorama_key,temp_name,com_force):
    if (com_force == True):
        # Force commit can be removed after the panorama bug is fixed/backported.
        logger.info( "commit force on panorama")
        cmd = "<commit><force></force></commit>"
        ok, res = commit_panorama(panorama_ip, panorama_key, cmd)
        if not ok:
            logger.info("Not able to commit force")
            return False
        else:
            logger.info("Commit force completed")
        
    else:
        logger.info ("com_force= false")

    return True
 
def commit_panorama(panorama_ip, panorama_key, cmd):
    """
    Execute a commit command on panorama. This function will block until the commit finishes.
 
    :param panorama_ip:
    :param panorama_key:
    :param cmd:
    :return:
    """
    url = "https://" + panorama_ip + "/api"
    url += "?" + urllib.parse.urlencode({
        "type": "commit",
        "key": panorama_key,
        "cmd": cmd
    })
    ok, res = execute_command(url)
    if 'result' in res:
        # Job Enqueued, wait for finish
        job_id = res['result']['job']
        logger.info('Waiting for job: {}'.format(job_id))
        success = wait_for_job(panorama_ip, panorama_key, job_id, 0.5)
        logger.info('Job finished. COMMIT {}'.format("SUCCESS" if success else "FAILURE"))
        if not success:
            logger.error('Commit failed on panorama. Job id: {}'.format(job_id))
        return success, res
    return ok, res

def commitall_panorama(panorama_ip, panorama_key, cmd, dg_name):
    """
    Execute a commitall command on panorama. This function will block until the commit finishes.

    :param panorama_ip:
    :param panorama_key:
    :param cmd:
    :return:
    """
    url = "https://" + panorama_ip + "/api"
    url += "?" + urllib.parse.urlencode({
        "type": "commit",
        "action": "all",
        "key": panorama_key,
        "cmd": cmd
    })
    ok, res = execute_command(url)
    if 'result' in res:
        # Job Enqueued, wait for finish
        job_id = res['result']['job']
        logger.info('Waiting for job: {}'.format(job_id))
        success = wait_for_job(panorama_ip, panorama_key, job_id, 0.5)
        logger.info('Job finished. COMMIT {}'.format("SUCCESS" if success else "FAILURE"))
        if not success:
            logger.error('Commit failed on panorama. Job id: {}'.format(job_id))
            serial_no_list = get_serialno_disconnected_devices_in_dg(panorama_ip,panorama_key,dg_name)
            for i in serial_no_list:
                print (' serial number of the disconnected vms in the DG is :{}'.format(i))
        return success, res
    return ok, res

 
def get_job_status(panorama_ip, panorama_key, job_id):
    """
    Gets the status of the job on panorama.
    """
    url = "https://{}/api/?type=op&cmd=<show><jobs><id>{}</id></jobs></show>&key={}".format(panorama_ip, job_id, panorama_key)
    ok, result = execute_command(url, ret_dict=True)
    if not ok:
        logger.error("Getting job status failed for id: {} RESULT: {}".format(job_id, result))
    return ok, result
 
def wait_for_job(panorama_ip, panorama_key, job_id, interval):
    """
    Polls every `interval` seconds for the status of the job associated with the job_id.
    If the job status reachs 'FIN' then the function returns True. If any error occurs, False is returned.
    """
    while True:
        time.sleep(interval)
        success, result = get_job_status(panorama_ip, panorama_key, job_id)
        if not success:
            logger.error("API error while getting job status for id: {}".format(job_id))
            return False
        status = result['job']['status']
        if status == 'FIN':
            logger.info('Finished job {} with result: {}'.format(job_id, result))
            if result['job']['result'] == 'FAIL':
                return False
            return True
 
def get_default_ssl_context():
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx

def execute_command( url, ret_dict=True):
    ctx = get_default_ssl_context()
    print('Executed URL %s' % url)
    try:
        req = urllib.request.Request(url)
        response = urlopen(req, context=ctx)
        xml_resp = response.read().decode('utf-8')

            # If you want to return the response as xml.

        if not ret_dict:
            return (True, ET.fromstring(xml_resp))

        o = xmltodict.parse(xml_resp, force_list=['entry'])
    except Exception as e:
        print('Execution of cmd failed with %s' % str(e))
        return (False, str(e))

    if o['response']['@status'].lower() == 'success':
        if 'type=op' in url or 'action=get' \
            in url:
            return (True, o['response']['result'])
        return (True, o['response'])
    else:
        return (False, o['response'])

def get_devices_in_dg(panorama_ip,panorama_key,dg_name):
    url = "https://" + panorama_ip + "/api/?type=config&action=get&key=" + panorama_key
    url += "&xpath=/config/devices/entry[@name='localhost.localdomain']/"
    url += "device-group/entry[@name='" + dg_name + "']/devices"

    ok, result = execute_command(url, ret_dict=True)
    if not ok:
        logger.info("Getting device list from DG %s failed %s" % (dg_name, result))
    return ok, result        

def get_devices_in_tempstack(panorama_ip,panorama_key,temp_name):
    url = "https://" + panorama_ip + "/api/?type=config&action=get&key=" + panorama_key
    url += "&xpath=/config/devices/entry[@name='localhost.localdomain']/"
    url += "template-stack/entry[@name='" + temp_name + "']/devices"

    ok, result = execute_command(url, ret_dict=True)
    if not ok:
        print("Getting device list from templatestack %s failed %s" % (temp_name, result))
    return ok, result

def config_nlb_static_routes_panorama(panorama_ip,panorama_key,panorama_user,dg_name,nlb_vpc,temp_name,trust_def_gw,nlb_vpc_cidr=None):
    """

    :param
    :return:
    """
    
    logger.info('Add static routes for NLB-as-ILB')
    set_xpath = "https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']"
    # 4.Add Static route entry in the virtual router 
 
    #if static_route == True:

    # Look up VPC CIDR if not set (in same VPC/NLB Endpoint case)
    if not nlb_vpc_cidr:
        response = ec2_client.describe_vpcs(VpcIds=[nlb_vpc])
        for r in response['Vpcs']:
            vpc_cidr= r['CidrBlock']
    else:
        vpc_cidr = nlb_vpc_cidr
            
    for i in range (len(trust_def_gw)):
        vr_name=""+'VR-'+temp_name+""
        stroute_name='st-{}ilb-for-nlb'.format(str(i))
        pm_name='pm-st-{}ilb-for-nlb'.format(str(i))
        metric="10"
        metric = int(metric) + i
        metric_value = str(metric)
        nexthop= trust_def_gw[i]
        #url="https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='"+ vr_name +"']/routing-table/ip/static-route/entry[@name='"+ stroute_name +"']"
        url = set_xpath + "/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='"+ vr_name +"']/routing-table/ip/static-route/entry[@name='"+ stroute_name +"']"
        url +="&element=<interface>ethernet1/2</interface><destination>"+ vpc_cidr +"</destination><metric>"+ metric_value +"</metric><nexthop><ip-address>"+ nexthop +"</ip-address></nexthop>"
        ok, res = execute_command(url)
        if not ok:
            logger.info("Not able to create  static route  %s in %s" % (vr_name,temp_name))
            
        #url="https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='"+ vr_name +"']/routing-table/ip/static-route/entry[@name='"+ stroute_name +"']/path-monitor&"
        url = set_xpath + "/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='" + vr_name + "']/routing-table/ip/static-route/entry[@name='" + stroute_name + "']/path-monitor&"
        url += urllib.parse.urlencode({"element":"<enable>yes</enable><monitor-destinations><entry name='"+ pm_name +"'><enable>yes</enable><destination>"+ nexthop +"</destination><source>DHCP</source><count>5</count><interval>3</interval></entry></monitor-destinations>"})
        ok, res = execute_command(url)
        if not ok:
            logger.info("Not able to add path monitoring to static route %s in %s" % (stroute_name,vr_name))
    #else:
     #   logger.info("Skipping static route addition for same VPC")          
    
   # 5.Commit the changes locally to panorama
    logger.info("Commit the changes locally to panorama")
    cmd = '<partial><admin><member>{}</member></admin><device-group><member>{}</member></device-group><template-stack><member>{}</member></template-stack></partial>'.format(panorama_user, dg_name, temp_name)
    ok, res = commit_panorama(panorama_ip, panorama_key, cmd)
    if not ok:
        print("Committing changes locally to panorama failed")
    else:
        print("Committing changes locally to panorama succeeded")

    return True

def config_firewall_add_nat_rule_panorama(panorama_ip,panorama_key,panorama_user,dg_name,dns_name,nlb_port,nlb_vpc,temp_name,trust_def_gw,ilb_type,same_vpc=False,nlb_vpc_cidr=None):
    """

    :param
    :return:
    """
    
    logger.info('Add firewall NAT rule port: {} ip: {}'.format(nlb_port, dns_name))
    set_xpath = "https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']"
    # 1.Add service tcp/port for NAT
    service_name=""+'tcp'+str(nlb_port)+""
    #url = "https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='"+dg_name+"']/service/entry[@name='"+service_name+"']/protocol/tcp"
    url = set_xpath + "/device-group/entry[@name='" + dg_name + "']/service/entry[@name='" + service_name + "']/protocol/tcp"
    url += "&element=<port>"+str(nlb_port)+"</port>"
    ok, res = execute_command(url)
    if not ok:
        logger.info("Not able to set service for NAT  %s in %s" % (nlb_port, dg_name))
    
    # 2.Add Address Object
    object_addrsname=""+'ilb-on'+str(nlb_port)+""
    #url="https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='"+dg_name+"']/address/entry[@name='"+object_addrsname+"']"
    url = set_xpath + "/device-group/entry[@name='" + dg_name + "']/address/entry[@name='" + object_addrsname + "']"
    url +="&element=<fqdn>"+dns_name+"</fqdn>"
    ok, res = execute_command(url)
    if not ok:
        logger.info("Not able to create  Address object  %s in %s" % (object_addrsname, dg_name))
        
    #3.Add NAT rule
    nat_rule_name="'"+'natrule-port'+str(nlb_port)+"'"
    #url = "https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='"+dg_name+"']/pre-rulebase/nat/rules/entry[@name="+nat_rule_name+"]"
    url = set_xpath + "/device-group/entry[@name='" + dg_name + "']/pre-rulebase/nat/rules/entry[@name=" + nat_rule_name + "]"
    url += "&element=<description>NatRuleforInternalLoadBalancer</description><nat-type>ipv4</nat-type><from><member>any</member></from><to><member>untrust</member></to><service>"+service_name+"</service><to-interface>ethernet1/1</to-interface><source><member>any</member></source><destination><member>any</member></destination><source-translation><dynamic-ip-and-port><interface-address><interface>ethernet1/2</interface></interface-address></dynamic-ip-and-port></source-translation>"
    ok, res = execute_command(url)
    if not ok:
        logger.info("Not able to create NAT-rule-originalpacket  %s in %s" % (nat_rule_name, dg_name))
    #url = "https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='"+dg_name+"']/pre-rulebase/nat/rules/entry[@name="+nat_rule_name+"]/dynamic-destination-translation"
    url = set_xpath + "/device-group/entry[@name='" + dg_name + "']/pre-rulebase/nat/rules/entry[@name=" + nat_rule_name + "]/dynamic-destination-translation"
    url += "&element=<translated-address>"+object_addrsname+"</translated-address><translated-port>80</translated-port>"
    ok, res = execute_command(url)
    if not ok:
        logger.info("Not able to create NAT-rule-dst-translatedpacket  %s in %s" % (nat_rule_name, dg_name))
        
    # 4.Add Static route entry in the virtual router only for ALB-as-ILB applications; NLB routes are set up at init time.
 
    #if static_route == True:

    if ilb_type == 'application' and not same_vpc:
        logger.info("Configuring static route addition for ALB application")
        # Look up VPC CIDR if not set (in same VPC/NLB Endpoint case)
        if not nlb_vpc_cidr:
            response = ec2_client.describe_vpcs(VpcIds=[nlb_vpc])
            for r in response['Vpcs']:
                vpc_cidr= r['CidrBlock']
        else:
            vpc_cidr = nlb_vpc_cidr
            
        for i in range (len(trust_def_gw)):
            vr_name=""+'VR-'+temp_name+""
            stroute_name=""+'st-'+str(i)+'ilb-on-'+str(nlb_port)+""
            pm_name=""+'pm-st-'+str(i)+'ilb-on-'+str(nlb_port)+""
            metric="10"
            metric = int(metric) + i
            metric_value = str(metric)
            nexthop= trust_def_gw[i]
            #url="https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='"+ vr_name +"']/routing-table/ip/static-route/entry[@name='"+ stroute_name +"']"
            url = set_xpath + "/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='"+ vr_name +"']/routing-table/ip/static-route/entry[@name='"+ stroute_name +"']"
            url +="&element=<interface>ethernet1/2</interface><destination>"+ vpc_cidr +"</destination><metric>"+ metric_value +"</metric><nexthop><ip-address>"+ nexthop +"</ip-address></nexthop>"
            ok, res = execute_command(url)
            if not ok:
                logger.info("Not able to create  static route  %s in %s" % (vr_name,temp_name))
            
            #url="https://" + panorama_ip + "/api/?type=config&action=set&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='"+ vr_name +"']/routing-table/ip/static-route/entry[@name='"+ stroute_name +"']/path-monitor&"
            url = set_xpath + "/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='" + vr_name + "']/routing-table/ip/static-route/entry[@name='" + stroute_name + "']/path-monitor&"
            url += urllib.parse.urlencode({"element":"<enable>yes</enable><monitor-destinations><entry name='"+ pm_name +"'><enable>yes</enable><destination>"+ nexthop +"</destination><source>DHCP</source><count>5</count><interval>3</interval></entry></monitor-destinations>"})
            ok, res = execute_command(url)
            if not ok:
                logger.info("Not able to add path monitoring to static route %s in %s" % (stroute_name,vr_name))
    else:
        logger.info("Skipping static route addition for NLB application")
        
    # 5.Commit the changes locally to panorama
    logger.info("Commit the changes locally to panorama")
    cmd = '<partial><admin><member>{}</member></admin><device-group><member>{}</member></device-group><template-stack><member>{}</member></template-stack></partial>'.format(panorama_user, dg_name, temp_name)
    ok, res = commit_panorama(panorama_ip, panorama_key, cmd)
    if not ok:
        print("Committing changes locally to panorama failed")
    else:
        print("Committing changes locally to panorama succeeded")

    # 6.Commit the changes to DG and TS
    logger.info("Commit the changes to DG and TS")
    cmd = '<commit-all><shared-policy><device-group><entry name="{}"/></device-group><include-template>yes</include-template><merge-with-candidate-cfg>yes</merge-with-candidate-cfg><force-template-values>no</force-template-values><validate-only>no</validate-only></shared-policy></commit-all>'.format(dg_name)
    ok, res = commitall_panorama(panorama_ip, panorama_key, cmd, dg_name)
    if not ok:
        print("Committing changes to DG %s failed" % dg_name)
    else:
        print("Committing changes to DG %s successful" % dg_name)

    return True

def delete_nlb_static_routes_panorama(panorama_ip,panorama_key,panorama_user,dg_name,trust_def_gw,temp_name):
    """
    Delete static routes for NLB-as-ILB applications.
    :param
    :return:
    """
    logger.info('Delete static routes for NLB-as-ILB')
    delete_xpath = "https://" + panorama_ip + "/api/?type=config&action=delete&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']"
    # 4.Delete Static route entry in the virtual router 
    for i in range (len(trust_def_gw)):
        vr_name=""+'VR-'+temp_name+""
        stroute_name='st-{}ilb-for-nlb'.format(str(i))
        #url="https://" + panorama_ip + "/api/?type=config&action=delete&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='"+ vr_name +"']/routing-table/ip/static-route/entry[@name='"+ stroute_name +"']"
        url= delete_xpath +"/template-stack/entry[@name='" + temp_name + "']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='" +  vr_name  + "']/routing-table/ip/static-route/entry[@name='" + stroute_name + "']"
        ok, res = execute_command(url)        
        if not ok:
            print("Not able to delete  static route  %s in %s" % (vr_name,temp_name))

   # 5.Commit the changes locally to panorama
    logger.info("Commit the changes locally to panorama")
    cmd = '<partial><admin><member>{}</member></admin><device-group><member>{}</member></device-group><template-stack><member>{}</member></template-stack></partial>'.format(panorama_user, dg_name, temp_name)
    ok, res = commit_panorama(panorama_ip, panorama_key, cmd)
    if not ok:
        print("Committing changes locally to panorama failed")
    else:
        print("Committing changes locally to panorama succeeded")

    return True

def config_firewall_delete_nat_rule_panorama(panorama_ip,panorama_key,panorama_user,dg_name,dns_names,nlb_ports,trust_def_gw,temp_name,ilb_type,same_vpc=False, skip_commitall=False):
    """

    :param
    :return:
    """
    for nlb_port in nlb_ports:
        logger.info('Delete firewall NAT rule port: {} ip: {}'.format(nlb_port, dns_names))
        delete_xpath = "https://" + panorama_ip + "/api/?type=config&action=delete&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']"
        #1.Delete NAT rule
        nat_rule_name="'"+'natrule-port'+str(nlb_port)+"'"
        #url = "https://" + panorama_ip + "/api/?type=config&action=delete&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='"+dg_name+"']/pre-rulebase/nat/rules/entry[@name="+nat_rule_name+"]"
        url = delete_xpath + "/device-group/entry[@name='" + dg_name + "']/pre-rulebase/nat/rules/entry[@name=" + nat_rule_name + "]"
        ok, res = execute_command(url)
        if not ok:
            logger.info("Not able to delete NAT-rule-originalpacket  %s in %s" % (nat_rule_name, dg_name))
    
        # 2.Delete service tcp/port for NAT
        service_name=""+'tcp'+str(nlb_port)+""
        #url = "https://" + panorama_ip + "/api/?type=config&action=delete&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='"+dg_name+"']/service/entry[@name='"+service_name+"']"
        url = delete_xpath +"/device-group/entry[@name='"+ dg_name + "']/service/entry[@name='" + service_name + "']"
        ok, res = execute_command(url)
        if not ok:
            logger.info("Not able to delete service for NAT  %s in %s" % (nlb_port, dg_name))
    
        # 3.Delete Address Object
        object_addrsname=""+'ilb-on'+str(nlb_port)+""
        #url = "https://" + panorama_ip + "/api/?type=config&action=delete&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/device-group/entry[@name='"+dg_name+"']/address/entry[@name='"+object_addrsname+"']"
        url = delete_xpath +"/device-group/entry[@name='" + dg_name + "']/address/entry[@name='" + object_addrsname + "']"
        ok, res = execute_command(url)
        if not ok:
            logger.info("Not able to delete  Address object  %s in %s" % (object_addrsname, dg_name))
    
        # Only delete static routes if application is ALB, and application is deployed in separate VPC.
        if ilb_type == 'application' and not same_vpc:
            # 4.Delete Static route entry in the virtual router 
            for i in range (len(trust_def_gw)):
                vr_name=""+'VR-'+temp_name+""
                stroute_name=""+'st-'+str(i)+'ilb-on-'+str(nlb_port)+""
                #url="https://" + panorama_ip + "/api/?type=config&action=delete&key=" + panorama_key + "&xpath=/config/devices/entry[@name='localhost.localdomain']/template-stack/entry[@name='"+ temp_name +"']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='"+ vr_name +"']/routing-table/ip/static-route/entry[@name='"+ stroute_name +"']"
                url= delete_xpath +"/template-stack/entry[@name='" + temp_name + "']/config/devices/entry[@name='localhost.localdomain']/network/virtual-router/entry[@name='" +  vr_name  + "']/routing-table/ip/static-route/entry[@name='" + stroute_name + "']"
                ok, res = execute_command(url)        
                if not ok:
                    print("Not able to delete  static route  %s in %s" % (vr_name,temp_name))

   # 5.Commit the changes locally to panorama
    logger.info("Commit the changes locally to panorama")
    cmd = '<partial><admin><member>{}</member></admin><device-group><member>{}</member></device-group><template-stack><member>{}</member></template-stack></partial>'.format(panorama_user, dg_name, temp_name)
    ok, res = commit_panorama(panorama_ip, panorama_key, cmd)
    if not ok:
        print("Committing changes locally to panorama failed")
    else:
        print("Committing changes locally to panorama succeeded")

    if not skip_commitall:
        # 6.Commit the changes to DG and TS
        logger.info("Commit the changes to DG and TS")
        cmd = '<commit-all><shared-policy><device-group><entry name="{}"/></device-group><include-template>yes</include-template><merge-with-candidate-cfg>yes</merge-with-candidate-cfg><force-template-values>no</force-template-values><validate-only>no</validate-only></shared-policy></commit-all>'.format(dg_name)
        ok, res = commitall_panorama(panorama_ip, panorama_key, cmd, dg_name)
        if not ok:
            print("Committing changes to DG  %s and TS %s failed" % (dg_name,temp_name) )
        else:
            print("Committing changes to DG  %s and TS %s" % (dg_name,temp_name))           
    
    return True       

def config_firewall_commit(gcontext, gwMgmtIp, api_key):
    """

    :param gcontext:
    :param gwMgmtIp:
    :param api_key:
    :return:
    """
    pan_print('Commit configuration on firewall: {}'.format(gwMgmtIp))

    fw_cmd="https://"+gwMgmtIp+"/api/?type=commit&cmd=<commit></commit>&key="+api_key
    try:
        response = runCommand(gcontext, fw_cmd, gwMgmtIp, api_key)
        if response is None:
            pan_print('CFG_FW_CW_COMMIT: Failed to run command: ' + fw_cmd)
            return False
    except Exception as e:
         #logger.error("[Commit RESPONSE]: {}".format(e))
         pan_print("[CFG_FW_CW_COMMIT RESPONSE]: {}".format(e))
         return False

    return True

def pending_panorama_commits(panorama_ip, pano_api_key):
    """
    Check for pending commits on panorama.

    :param panorama_ip: IP address of Panorama
    :param pano_api_key: XML API key of Panorama
    :return: True (pending commits exist), False (no pending commits)
    """
    pan_print('Check for pending commits on panorama: {}'.format(panorama_ip))

    cmd_commit_pending  = "/api/?type=op&cmd=<show><jobs><pending/></jobs></show>&key="+pano_api_key
    try:
        conn = HTTPSConnection(panorama_ip, 443, timeout=10, context=ssl._create_unverified_context())
        response = send_command(conn, cmd_commit_pending)
    except Exception as e:
        logger.error('Exception: Fail to execute API on Panorama {}: {}'.format(panorama_ip, e))
        return False

    if response['result'] == False:
        conn.close()
        logger.error('Fail to execute Panorama API to show pending commits: {}'.format(panorama_ip))
        return False

    conn.close()

    result = response['data'].find('result')
    if len(result):
        logger.info('Pending commits exist on Panorama: {}'.format(panorama_ip))
        return True
    else:
        logger.info('No pending commits exist on Panorama: {}'.format(panorama_ip))
        return False

